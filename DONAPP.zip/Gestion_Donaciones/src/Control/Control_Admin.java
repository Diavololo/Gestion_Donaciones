package Control;

import Modelo.Organizacion;
import Modelo.Usuario;
import Vista.Vista_Admin;
import Vista.Vista_Login;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Controlador principal para la interfaz de administrador.
 * Gestiona:
 *   - Navegación entre secciones (organizaciones/usuarios)
 *   - Operaciones CRUD completas para organizaciones
 *   - Operaciones CRUD completas para usuarios
 *   - Validación de datos y manejo de errores
 *   - Redireccionamiento entre vistas
 * 
 * Coordina las operaciones entre Vista_Admin y los modelos de datos.
 */
public class Control_Admin implements ActionListener {

    Vista_Admin vista_admin; // Vista asociada

    public Control_Admin(Vista_Admin vista_admin) {
        this.vista_admin = vista_admin; // Vincula vista al controlador
    }

    /**
     * Maneja todos los eventos de la interfaz administrativa:
     *   - Navegación entre menús (organizaciones/usuarios)
     *   - CRUD de organizaciones (añadir/editar/eliminar/ver)
     *   - CRUD de usuarios (añadir/editar/eliminar/ver)
     *   - Búsquedas específicas por ID/correo
     *   - Volver a menú principal o login
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        // Menú Organizaciones
        if (e.getSource().equals(vista_admin.jbMenuOrganizacion)) {
            vista_admin.remove(vista_admin.jbVolver);
            vista_admin.remove(vista_admin.jbMenuCampañas);
            vista_admin.remove(vista_admin.jbMenuOrganizacion);
            vista_admin.remove(vista_admin.jbMenuUsuarios);

            vista_admin.Menu_Organizacion();
        }

        if (e.getSource().equals(vista_admin.jbVolver)) {
            evento_volver();
        }

        // Gestión de organizaciones
        if (e.getSource().equals(vista_admin.jbAñadirOrg)) {
            vista_admin.remove(vista_admin.jbAñadirOrg);
            vista_admin.remove(vista_admin.jbEditarOrg);
            vista_admin.remove(vista_admin.jbEliminarOrg);
            vista_admin.remove(vista_admin.jbVerOrg);
            vista_admin.remove(vista_admin.jlAñadirOrg);
            vista_admin.remove(vista_admin.jlEditarOrg);
            vista_admin.remove(vista_admin.jlEliminarOrg);
            vista_admin.remove(vista_admin.jlVerOrg);

            vista_admin.add(vista_admin.jlLlave);
            vista_admin.add(vista_admin.jtLlave);
            vista_admin.add(vista_admin.jlNombre);
            vista_admin.add(vista_admin.jtNombre);
            vista_admin.add(vista_admin.jlContacto);
            vista_admin.add(vista_admin.jtContacto);
            vista_admin.add(vista_admin.jbAddOrg);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbAddOrg)) {
            boolean existe = false;

            Organizacion organizacion = new Organizacion();
            List<Organizacion> resultados = organizacion.selectOrganizaciones();
            long llave = Long.parseLong(vista_admin.jtLlave.getText());

            for (Organizacion org : resultados) {
                if (org.getID() == llave) {
                    existe = true;
                }
            }

            if (existe) {
                JOptionPane.showMessageDialog(null, "Error Llave ya registrada");
            } else {
                long id = Long.parseLong(vista_admin.jtLlave.getText());
                String nombre = vista_admin.jtNombre.getText();
                String contacto = vista_admin.jtContacto.getText();

                Organizacion org = new Organizacion(id, nombre, contacto);
                boolean guardado = org.guardar();
                if (guardado) {
                    JOptionPane.showMessageDialog(null, "se ha registrado con exito");
                    evento_volver_admin();
                } else {
                    JOptionPane.showMessageDialog(null, "NO se ha podido registrar");
                }
            }
        }

        if (e.getSource().equals(vista_admin.jbEditarOrg)) {
            vista_admin.remove(vista_admin.jbAñadirOrg);
            vista_admin.remove(vista_admin.jbEliminarOrg);
            vista_admin.remove(vista_admin.jbEditarOrg);
            vista_admin.remove(vista_admin.jbVerOrg);
            vista_admin.remove(vista_admin.jlAñadirOrg);
            vista_admin.remove(vista_admin.jlEditarOrg);
            vista_admin.remove(vista_admin.jlEliminarOrg);
            vista_admin.remove(vista_admin.jlVerOrg);

            vista_admin.add(vista_admin.jlLlave);
            vista_admin.add(vista_admin.jtLlave);
            vista_admin.add(vista_admin.jbBuscarEditarOrg);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbBuscarEditarOrg)) {
            if (vista_admin.jtLlave.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Llave no encontrada");
            } else {
                Organizacion organizacion = new Organizacion();
                organizacion = organizacion.selectOrganizacion(Long.parseLong(vista_admin.jtLlave.getText()));

                vista_admin.jtNombre.setText(organizacion.getNombre());
                vista_admin.jtContacto.setText(organizacion.getContacto());

                vista_admin.remove(vista_admin.jbBuscarEditarOrg);
                vista_admin.jtLlave.setEnabled(false);

                vista_admin.add(vista_admin.jlNombre);
                vista_admin.add(vista_admin.jtNombre);
                vista_admin.add(vista_admin.jlContacto);
                vista_admin.add(vista_admin.jtContacto);
                vista_admin.add(vista_admin.jbEditOrg);

                vista_admin.revalidate();
                vista_admin.repaint();
            }
        }

        if (e.getSource().equals(vista_admin.jbEditOrg)) {
            boolean existe = false;

            Organizacion organizacion = new Organizacion();
            List<Organizacion> resultados = organizacion.selectOrganizaciones();
            long llave = Long.parseLong(vista_admin.jtLlave.getText());

            for (Organizacion org : resultados) {
                if (org.getID() == llave) {
                    existe = true;
                }
            }

            if (existe) {
                long id = Long.parseLong(vista_admin.jtLlave.getText());
                String nombre = vista_admin.jtNombre.getText();
                String contacto = vista_admin.jtContacto.getText();

                Organizacion org = new Organizacion(id, nombre, contacto);
                boolean guardado = org.actualizar(id);
                if (guardado) {
                    JOptionPane.showMessageDialog(null, "se ha editado con exito");
                    evento_volver_admin();
                } else {
                    JOptionPane.showMessageDialog(null, "NO se ha podido editar");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Organizacion no encontrada");
            }
        }

        if (e.getSource().equals(vista_admin.jbEliminarOrg)) {
            vista_admin.remove(vista_admin.jbAñadirOrg);
            vista_admin.remove(vista_admin.jbEditarOrg);
            vista_admin.remove(vista_admin.jbEliminarOrg);
            vista_admin.remove(vista_admin.jbVerOrg);
            vista_admin.remove(vista_admin.jlAñadirOrg);
            vista_admin.remove(vista_admin.jlEditarOrg);
            vista_admin.remove(vista_admin.jlEliminarOrg);
            vista_admin.remove(vista_admin.jlVerOrg);

            vista_admin.add(vista_admin.jlLlave);
            vista_admin.add(vista_admin.jtLlave);
            vista_admin.add(vista_admin.jbDeleteOrg);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbDeleteOrg)) {
            boolean existe = false;

            Organizacion organizacion = new Organizacion();
            List<Organizacion> resultados = organizacion.selectOrganizaciones();
            long llave = Long.parseLong(vista_admin.jtLlave.getText());

            for (Organizacion org : resultados) {
                if (org.getID() == llave) {
                    existe = true;
                }
            }

            if (existe) {
                long id = Long.parseLong(vista_admin.jtLlave.getText());

                Organizacion org = new Organizacion(id, "", "");
                boolean eliminado = org.eliminar(id);
                if (eliminado) {
                    JOptionPane.showMessageDialog(null, "se ha eliminado con exito");
                    evento_volver_admin();
                } else {
                    JOptionPane.showMessageDialog(null, "NO se ha podido eliminar");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Organizacion no encontrada");
            }
        }

        if (e.getSource().equals(vista_admin.jbVerOrg)) {
            vista_admin.remove(vista_admin.jbAñadirOrg);
            vista_admin.remove(vista_admin.jbEditarOrg);
            vista_admin.remove(vista_admin.jbEliminarOrg);
            vista_admin.remove(vista_admin.jbVerOrg);
            vista_admin.remove(vista_admin.jlAñadirOrg);
            vista_admin.remove(vista_admin.jlEditarOrg);
            vista_admin.remove(vista_admin.jlEliminarOrg);
            vista_admin.remove(vista_admin.jlVerOrg);

            String[] fila = new String[3];
            Organizacion organizacion = new Organizacion();
            List<Organizacion> resultados = organizacion.selectOrganizaciones();
            for (Organizacion resultado : resultados) {
                fila[0] = Long.toString(resultado.getID());
                fila[1] = resultado.getNombre();
                fila[2] = resultado.getContacto();
                vista_admin.dt.addRow(fila);
            }

            vista_admin.add(vista_admin.js);
            vista_admin.add(vista_admin.jbBuscarVerOrg);
            vista_admin.add(vista_admin.jlBuscarVerOrg);
            vista_admin.add(vista_admin.jtBuscarVer);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbBuscarVerOrg)) {
            vista_admin.dt.setRowCount(0);

            Organizacion organizacion = new Organizacion();
            organizacion = organizacion.selectOrganizacion(Long.parseLong(vista_admin.jtBuscarVer.getText()));

            String[] fila = new String[3];
            fila[0] = Long.toString(organizacion.getID());
            fila[1] = organizacion.getNombre();
            fila[2] = organizacion.getContacto();

            vista_admin.dt.addRow(fila);
        }

        if (e.getSource().equals(vista_admin.jbVolverOrg)) {
            evento_volver_admin();
        }

        //Menu Usuarios
        if (e.getSource().equals(vista_admin.jbMenuUsuarios)) {
            vista_admin.remove(vista_admin.jbVolver);
            vista_admin.remove(vista_admin.jbMenuCampañas);
            vista_admin.remove(vista_admin.jbMenuOrganizacion);
            vista_admin.remove(vista_admin.jbMenuUsuarios);

            vista_admin.Menu_Usuarios();
        }

        // Gestión de usuarios
        if (e.getSource().equals(vista_admin.jbAñadirUsuario)) {
            vista_admin.remove(vista_admin.jbAñadirUsuario);
            vista_admin.remove(vista_admin.jbEditarUsuario);
            vista_admin.remove(vista_admin.jbEliminarUsuario);
            vista_admin.remove(vista_admin.jbVerUsuario);
            vista_admin.remove(vista_admin.jlAñadirUsuario);
            vista_admin.remove(vista_admin.jlEditarUsuario);
            vista_admin.remove(vista_admin.jlEliminarUsuario);
            vista_admin.remove(vista_admin.jlVerUsuario);

            vista_admin.add(vista_admin.jlNombreUsuario);
            vista_admin.add(vista_admin.jtNombreUsuario);
            vista_admin.add(vista_admin.jlApellidoUsuario);
            vista_admin.add(vista_admin.jtApellidoUsuario);
            vista_admin.add(vista_admin.jlCorreoUsuario);
            vista_admin.add(vista_admin.jtCorreoUsuario);
            vista_admin.add(vista_admin.jlContraseñaUsuario);
            vista_admin.add(vista_admin.jtContraseñaUsuario);
            vista_admin.add(vista_admin.jlTipoUsuario);
            vista_admin.add(vista_admin.jcTipoUsuario);
            vista_admin.add(vista_admin.jbAddUsuario);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbAddUsuario)) {
            boolean existe = false;

            Usuario usuario = new Usuario();
            List<Usuario> resultados = usuario.selectUsuarios();
            String correo = vista_admin.jtCorreoUsuario.getText();

            for (Usuario user : resultados) {
                if (user.getCorreo().equals(correo)) {
                    existe = true;
                }
            }

            if (existe) {
                JOptionPane.showMessageDialog(null, "Error: Correo ya registrado");
            } else {
                String nombre = vista_admin.jtNombreUsuario.getText();
                String apellido = vista_admin.jtApellidoUsuario.getText();
                String contraseña = vista_admin.jtContraseñaUsuario.getText();
                String tipo_usuario = vista_admin.jcTipoUsuario.getSelectedItem().toString();

                Usuario user = new Usuario(nombre, apellido, correo, contraseña, tipo_usuario);
                boolean guardado = user.guardar();
                if (guardado) {
                    JOptionPane.showMessageDialog(null, "Usuario registrado con éxito");
                    evento_volver_admin();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo registrar el usuario");
                }
            }
        }

        if (e.getSource().equals(vista_admin.jbEditarUsuario)) {
            vista_admin.remove(vista_admin.jbAñadirUsuario);
            vista_admin.remove(vista_admin.jbEliminarUsuario);
            vista_admin.remove(vista_admin.jbEditarUsuario);
            vista_admin.remove(vista_admin.jbVerUsuario);
            vista_admin.remove(vista_admin.jlAñadirUsuario);
            vista_admin.remove(vista_admin.jlEditarUsuario);
            vista_admin.remove(vista_admin.jlEliminarUsuario);
            vista_admin.remove(vista_admin.jlVerUsuario);

            vista_admin.jlCorreoUsuario.setText("Correo del usuario a editar:");
            vista_admin.add(vista_admin.jlCorreoUsuario);
            vista_admin.add(vista_admin.jtCorreoUsuario);
            vista_admin.add(vista_admin.jbBuscarEditarUsuario);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbBuscarEditarUsuario)) {
            if (vista_admin.jtCorreoUsuario.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Correo no encontrado");
            } else {
                Usuario usuario = new Usuario();
                usuario = usuario.selectUsuarioCorreo(vista_admin.jtCorreoUsuario.getText());

                vista_admin.jtNombreUsuario.setText(usuario.getNombre());
                vista_admin.jtApellidoUsuario.setText(usuario.getApellido());
                vista_admin.jtContraseñaUsuario.setText(usuario.getContraseña());

                vista_admin.remove(vista_admin.jbBuscarEditarUsuario);
                vista_admin.jlCorreoUsuario.setText("Correo:");
                vista_admin.jtCorreoUsuario.setEnabled(false);

                vista_admin.add(vista_admin.jlNombreUsuario);
                vista_admin.add(vista_admin.jtNombreUsuario);
                vista_admin.add(vista_admin.jlApellidoUsuario);
                vista_admin.add(vista_admin.jtApellidoUsuario);
                vista_admin.add(vista_admin.jlCorreoUsuario);
                vista_admin.add(vista_admin.jlContraseñaUsuario);
                vista_admin.add(vista_admin.jtContraseñaUsuario);
                vista_admin.add(vista_admin.jlTipoUsuario);
                vista_admin.add(vista_admin.jcTipoUsuario);
                vista_admin.add(vista_admin.jbEditUsuario);

                vista_admin.revalidate();
                vista_admin.repaint();
            }
        }

        if (e.getSource().equals(vista_admin.jbEditUsuario)) {
            String correo = vista_admin.jtCorreoUsuario.getText();
            String nombre = vista_admin.jtNombreUsuario.getText();
            String apellido = vista_admin.jtApellidoUsuario.getText();
            String contraseña = vista_admin.jtContraseñaUsuario.getText();
            String tipo_usuario = vista_admin.jcTipoUsuario.getSelectedItem().toString();

            Usuario usuario = new Usuario(nombre, apellido, correo, contraseña, tipo_usuario);
            boolean actualizado = usuario.actualizar(correo);
            if (actualizado) {
                JOptionPane.showMessageDialog(null, "Usuario editado con éxito");
                evento_volver_admin();
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo editar el usuario");
            }
        }

        if (e.getSource().equals(vista_admin.jbEliminarUsuario)) {
            vista_admin.remove(vista_admin.jbAñadirUsuario);
            vista_admin.remove(vista_admin.jbEditarUsuario);
            vista_admin.remove(vista_admin.jbEliminarUsuario);
            vista_admin.remove(vista_admin.jbVerUsuario);
            vista_admin.remove(vista_admin.jlAñadirUsuario);
            vista_admin.remove(vista_admin.jlEditarUsuario);
            vista_admin.remove(vista_admin.jlEliminarUsuario);
            vista_admin.remove(vista_admin.jlVerUsuario);

            vista_admin.jlCorreoUsuario.setText("Correo del usuario a eliminar:");
            vista_admin.add(vista_admin.jlCorreoUsuario);
            vista_admin.add(vista_admin.jtCorreoUsuario);
            vista_admin.add(vista_admin.jbDeleteUsuario);

            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbDeleteUsuario)) {
            String correo = vista_admin.jtCorreoUsuario.getText();

            int confirmacion = JOptionPane.showConfirmDialog(
                    null,
                    "¿Está seguro de que desea eliminar el usuario con correo: " + correo + "?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION
            );
            if (confirmacion == JOptionPane.YES_OPTION) {
                Usuario usuario = new Usuario();
                boolean eliminado = usuario.eliminar(correo);

                if (eliminado) {
                    JOptionPane.showMessageDialog(null, "Usuario eliminado con éxito");
                    evento_volver_admin();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar el usuario");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Eliminación cancelada");
            }
        }

        if (e.getSource().equals(vista_admin.jbVerUsuario)) {
            vista_admin.remove(vista_admin.jbAñadirUsuario);
            vista_admin.remove(vista_admin.jbEditarUsuario);
            vista_admin.remove(vista_admin.jbEliminarUsuario);
            vista_admin.remove(vista_admin.jbVerUsuario);
            vista_admin.remove(vista_admin.jlAñadirUsuario);
            vista_admin.remove(vista_admin.jlEditarUsuario);
            vista_admin.remove(vista_admin.jlEliminarUsuario);
            vista_admin.remove(vista_admin.jlVerUsuario);

            String[] fila = new String[4];
            Usuario usuario = new Usuario();
            List<Usuario> resultados = usuario.selectUsuarios();
            for (Usuario resultado : resultados) {
                fila[0] = resultado.getNombre();
                fila[1] = resultado.getApellido();
                fila[2] = resultado.getCorreo();
                fila[3] = resultado.getTipo_usuario();
                vista_admin.dt.addRow(fila);
            }

            vista_admin.add(vista_admin.js);
            vista_admin.revalidate();
            vista_admin.repaint();
        }

        if (e.getSource().equals(vista_admin.jbVolverUsuario)) {
            evento_volver_admin();
        }
    }

    /**
     * Restablece la vista de administrador a su estado inicial
     */
    public void evento_volver_admin() {
        // Recarga la vista administrativa
        vista_admin.removeAll();
        vista_admin.setVisible(false);
        vista_admin.dispose();
        vista_admin = new Vista_Admin(vista_admin.login);
    }

    /**
     * Regresa a la pantalla de login
     */
    public void evento_volver() {
        // Cierra sesion y muestra login
        vista_admin.setVisible(false);
        vista_admin.dispose();
        Vista_Login login = new Vista_Login();
    }
}
