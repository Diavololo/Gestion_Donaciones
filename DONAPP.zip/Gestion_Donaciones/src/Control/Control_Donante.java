package Control;

import Modelo.Campaña;
import Modelo.Donacion;
import Modelo.Meta;
import Vista.Vista_Donante;
import Vista.Vista_Login;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Controlador principal para la interfaz de donantes.
 * Gestiona:
 *   - Exploración de campañas activas
 *   - Realización de donaciones a campañas específicas
 *   - Visualización del historial de donaciones personales
 *   - Cálculo del total donado
 *   - Cierre de sesión y navegación
 * 
 * Coordina las operaciones entre Vista_Donante y los modelos de datos.
 */
public class Control_Donante implements ActionListener {

    private Vista_Donante vista_donante; // Vista asociada
    private String nombreCampaña; // Almacena campaña seleccionada temporalmente
 
    public Control_Donante(Vista_Donante vista_donante) {
        this.vista_donante = vista_donante; // Vincula vista al controlador
    }

    /**
     * Maneja todos los eventos de la interfaz del donante:
     *   - Visualización de campañas disponibles
     *   - Búsqueda y selección de campañas
     *   - Proceso de donación (selección de monto/método)
     *   - Confirmación de donaciones
     *   - Consulta de historial de donaciones
     *   - Navegación entre vistas
     *   - Cierre de sesión
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        // Ver campañas disponibles
        if (e.getSource().equals(vista_donante.jbVerCampañas)) {

            vista_donante.remove(vista_donante.jlDialogo);
            vista_donante.remove(vista_donante.jbVerCampañas);
            vista_donante.remove(vista_donante.jbRealizarDonacion);
            vista_donante.remove(vista_donante.jbVerDonaciones);
            vista_donante.remove(vista_donante.jbCerrar_sesion);

            vista_donante.jlSubTitulo.setText("Campañas Disponibles");

            vista_donante.add(vista_donante.jsVerCamp);
            vista_donante.add(vista_donante.jlBuscarCampaña);
            vista_donante.add(vista_donante.jtBuscarCampaña);
            vista_donante.add(vista_donante.jbBuscarCampaña);

            vista_donante.revalidate();
            vista_donante.repaint();

            String[] fila = new String[3];
            Campaña campaña = new Campaña();
            List<Campaña> resultados = campaña.selectCampañas();
            for (Campaña resultado : resultados) {
                fila[0] = resultado.getNombre();
                fila[1] = resultado.getFecha_fin();

                Meta meta = new Meta();
                meta = meta.selectMetaCampaña(resultado.getID());
                fila[2] = "$" + Long.toString(meta.getMeta_propuesta());

                vista_donante.dtVerCamp.addRow(fila);
            }
            vista_donante.revalidate();
            vista_donante.repaint();

        }

        // Buscar campaña
        if (e.getSource().equals(vista_donante.jbBuscarCampaña)) {
            String nombreCamp = vista_donante.jtBuscarCampaña.getText();
            String[] fila = new String[3];
            Campaña campaña = new Campaña();
            Campaña resultado = campaña.selectCampañaNombre(nombreCamp);

            if (resultado == null) {
                JOptionPane.showMessageDialog(null, "No se pudo encontrar la campaña", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                nombreCampaña = resultado.getNombre();
                vista_donante.jlFechaInicio.setText("Fecha de Inicio: " + resultado.getFecha_inicio());
                vista_donante.add(vista_donante.jlFechaInicio);
                vista_donante.jlFechaFin.setText("Fecha de Fin: " + resultado.getFecha_fin());
                vista_donante.add(vista_donante.jlFechaFin);
                vista_donante.jtDescripcion.setText(resultado.getDescripcion());
                vista_donante.add(vista_donante.jsDescripcion);
                vista_donante.add(vista_donante.jlDescripcion);
                vista_donante.add(vista_donante.jbRealizarDonacionCamp);

                Meta meta = new Meta();
                meta = meta.selectMetaCampaña(resultado.getID());
                vista_donante.jlMetaPropuesta.setText("Meta Propuesta: $" + Long.toString(meta.getMeta_propuesta()));
                vista_donante.add(vista_donante.jlMetaPropuesta);

                vista_donante.revalidate();
                vista_donante.repaint();
            }
        }

        // Realizar una donación
        if (e.getSource().equals(vista_donante.jbRealizarDonacion)) {
            vista_donante.remove(vista_donante.jlDialogo);
            vista_donante.remove(vista_donante.jbVerCampañas);
            vista_donante.remove(vista_donante.jbRealizarDonacion);
            vista_donante.remove(vista_donante.jbVerDonaciones);
            vista_donante.remove(vista_donante.jbCerrar_sesion);

            vista_donante.jlSubTitulo.setText("Realizar Donación");
            vista_donante.add(vista_donante.jlCampaña);
            vista_donante.add(vista_donante.jtCampaña);
            vista_donante.add(vista_donante.jlMonto);
            vista_donante.add(vista_donante.jtMonto);
            vista_donante.add(vista_donante.jlMetodo_pago);
            vista_donante.add(vista_donante.jcMetodo_pago);
            vista_donante.add(vista_donante.jbConfirmarDonacion);
            vista_donante.add(vista_donante.jbVolver);

            vista_donante.revalidate();
            vista_donante.repaint();
        }
        if (e.getSource().equals(vista_donante.jbRealizarDonacionCamp)) {
            vista_donante.remove(vista_donante.jsVerCamp);
            vista_donante.remove(vista_donante.jlBuscarCampaña);
            vista_donante.remove(vista_donante.jtBuscarCampaña);
            vista_donante.remove(vista_donante.jbBuscarCampaña);
            vista_donante.remove(vista_donante.jlFechaInicio);
            vista_donante.remove(vista_donante.jlFechaFin);
            vista_donante.remove(vista_donante.jsDescripcion);
            vista_donante.remove(vista_donante.jlDescripcion);
            vista_donante.remove(vista_donante.jbRealizarDonacionCamp);
            vista_donante.remove(vista_donante.jlMetaPropuesta);

            vista_donante.jlSubTitulo.setText("Realizar Donación");
            vista_donante.add(vista_donante.jlCampaña);
            vista_donante.jtCampaña.setText(nombreCampaña);
            vista_donante.add(vista_donante.jtCampaña);
            vista_donante.add(vista_donante.jlMonto);
            vista_donante.add(vista_donante.jtMonto);
            vista_donante.add(vista_donante.jlMetodo_pago);
            vista_donante.add(vista_donante.jcMetodo_pago);
            vista_donante.add(vista_donante.jbConfirmarDonacion);
            vista_donante.add(vista_donante.jbVolver);

            vista_donante.revalidate();
            vista_donante.repaint();
        }

        // Confirmar donación
        if (e.getSource().equals(vista_donante.jbConfirmarDonacion)) {
            String nombreCampaña = vista_donante.jtCampaña.getText();
            String metodo_pago = vista_donante.jcMetodo_pago.getSelectedItem().toString();
            Long monto = Long.parseLong(vista_donante.jtMonto.getText());

            Campaña campaña = new Campaña();
            Campaña resultado = campaña.selectCampañaNombre(nombreCampaña);

            if (resultado == null) {
                JOptionPane.showMessageDialog(null, "No se pudo encontrar la campaña", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Confirmación de la donación
                int confirmacion = JOptionPane.showConfirmDialog(
                        null,
                        "¿Está seguro de que desea donar $" + monto + " a la campaña \"" + nombreCampaña + "\"?",
                        "Confirmar Donación",
                        JOptionPane.YES_NO_OPTION
                );

                if (confirmacion == JOptionPane.YES_OPTION) {
                    // Crear donación
                    String fechaActual = LocalDate.now().toString(); // Obtener la fecha actual
                    Donacion donacion = new Donacion(monto, fechaActual, metodo_pago, vista_donante.usuario, resultado);
                    boolean guardado = donacion.guardar();

                    // Actualizar monto acumulado de la campaña
                    Meta meta = new Meta();
                    boolean acomulado = meta.actualizarAcomulado(resultado.getID(), monto);

                    if (guardado && acomulado) {
                        JOptionPane.showMessageDialog(null, "Donación realizada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        eventoVolver();
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al realizar la donación", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Donación cancelada", "Cancelado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }

        // Ver donaciones realizadas
        if (e.getSource().equals(vista_donante.jbVerDonaciones)) {
            vista_donante.remove(vista_donante.jlDialogo);
            vista_donante.remove(vista_donante.jbVerCampañas);
            vista_donante.remove(vista_donante.jbRealizarDonacion);
            vista_donante.remove(vista_donante.jbVerDonaciones);
            vista_donante.remove(vista_donante.jbCerrar_sesion);

            Long totalDonado = 0L;

            vista_donante.jlSubTitulo.setText("Donaciones Realizadas");
            vista_donante.add(vista_donante.jsVerDona);
            vista_donante.add(vista_donante.jbVolver);

            String[] fila = new String[4];
            Donacion donacion = new Donacion();
            List<Donacion> resultados = donacion.selectDonacionesUsuario(vista_donante.usuario);
            for (Donacion resultado : resultados) {

                totalDonado += resultado.getMonto();

                fila[0] = resultado.getCampaña().getNombre();
                fila[1] = Long.toString(resultado.getMonto());
                fila[2] = resultado.getFecha();
                fila[3] = resultado.getMetodo_pago();

                vista_donante.dtVerDona.addRow(fila);
            }

            vista_donante.jlTotalDonado.setText("Total Donado: $" + Long.toString(totalDonado));
            vista_donante.add(vista_donante.jlTotalDonado);

            vista_donante.revalidate();
            vista_donante.repaint();
        }

        // Volver a la vista anterior
        if (e.getSource().equals(vista_donante.jbVolver)) {
            eventoVolver();
        }

        // Cerrar sesión
        if (e.getSource().equals(vista_donante.jbCerrar_sesion)) {
            cerrarSesion();
        }
    }

    /**
     * Vuelve al menú principal del donante
     */
    private void eventoVolver() {
        vista_donante.removeAll();
        vista_donante.setVisible(false);
        Vista_Donante new_vista_donante = new Vista_Donante(vista_donante.login, vista_donante.usuario);
        vista_donante.dispose();
        // Recarga la vista del donante
    }

    /**
     * Cierra la sesión y regresa al login
     */
    private void cerrarSesion() {
        vista_donante.setVisible(false);
        Vista_Login login = new Vista_Login();
        login.setVisible(true);
        vista_donante.dispose();
        // Vuelve a la pantalla de inicio de sesión
    }
}
