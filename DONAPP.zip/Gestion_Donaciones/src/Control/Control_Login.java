package Control;

import Modelo.Organizacion;
import Modelo.Usuario;
import Vista.Vista_Admin;
import Vista.Vista_Donante;
import Vista.Vista_Login;
import Vista.Vista_Organizacion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Controlador principal para la ventana de login.
 * Gestiona:
 *   - Autenticación de usuarios (administradores/donantes)
 *   - Acceso de organizaciones mediante llave
 *   - Registro de nuevos usuarios
 *   - Cambio entre modos de interfaz (login/registro/organización)
 *   - Eventos de cierre de ventana
 * 
 * Coordina las operaciones entre Vista_Login y los modelos de datos.
 */
public class Control_Login implements ActionListener, WindowListener {

    public Vista_Login login; // Vista asociada

    public Control_Login(Vista_Login login) {
        this.login = login; // Vincula vista al controlador
    }

    /**
     * Maneja todos los eventos de acción en la ventana:
     *   - Inicio de sesión para usuarios y administradores
     *   - Registro de nuevos donantes
     *   - Acceso para organizaciones
     *   - Alternar visibilidad de contraseña
     *   - Navegación entre modos (login/registro/organización)
     *   - Cierre de la aplicación
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(login.jbIniciar_sesion)) {

            boolean existe = false;

            Usuario user = new Usuario();
            List<Usuario> resultados = user.selectUsuarios();
            for (Usuario usuario : resultados) {
                if (usuario.getCorreo().equals(login.jtCorreo.getText())) {
                    existe = true;
                }
            }
            if (existe) {

                user = user.selectUsuarioCorreo(login.jtCorreo.getText());

                String contraseñaIngresada = login.jpContraseña.getText();

                String contraseña = user.getContraseña();
                if (contraseña.equals(contraseñaIngresada)) {
                    if (user.getTipo_usuario().equals("administrador")) {
                        login.setVisible(false);
                        Vista_Admin vista_admin = new Vista_Admin(login);
                        login.dispose();
                    }
                    if (user.getTipo_usuario().equals("donante")) {
                        login.setVisible(false);
                        Vista_Donante vista_donante = new Vista_Donante(login, user);
                        login.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Contraseña Incorrecta");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Correo no registrado");
            }
        }
        
        if (e.getSource().equals(login.verContraseña)){
            if(login.verContraseña.isSelected()){
                login.verContraseña.setIcon(login.ver);
                login.jpContraseña.setEchoChar((char)0);
            }else{
                login.verContraseña.setIcon(login.no_ver);
                login.jpContraseña.setEchoChar('•');
            }
        }
        
        if (e.getSource().equals(login.jbRegistrarse)) {

            login.remove(login.jlSubTitulo);
            login.remove(login.jbIniciar_sesion);
            login.remove(login.jbRegistrarse);
            login.remove(login.jlOrganizacion);
            login.remove(login.jbOrganizacion);
            login.remove(login.jbRegistrarse);
            login.remove(login.jbSalir);
            login.add(login.jlSubTitulo2);
            login.add(login.jbApellido);
            login.add(login.jtApellido);
            login.add(login.jbNombre);
            login.add(login.jtNombre);
            login.add(login.jbRegistrar);
            login.add(login.jbVolverUser);
            login.add(login.jlSubTitulo2);
            login.add(login.jtApellido);
            login.add(login.jtNombre);
            login.add(login.jbRegistrar);
            login.add(login.jbVolverUser);

            login.revalidate();
            login.repaint();
        }

        if (e.getSource().equals(login.jbRegistrar)) {
            boolean existe = false;

            Usuario usuario = new Usuario();
            List<Usuario> resultados = usuario.selectUsuarios();
            for (Usuario user : resultados) {
                if (user.getCorreo().equals(login.jtCorreo.getText())) {
                    existe = true;
                }
            }
            if (existe) {
                JOptionPane.showMessageDialog(null, "Correo ya registrado");
            } else {

                String nombre = login.jtNombre.getText();
                String apellido = login.jtApellido.getText();
                String correo = login.jtCorreo.getText();
                String contraseña = login.jpContraseña.getText();

                Usuario user = new Usuario(nombre, apellido, correo, contraseña, "donante");
                boolean guardado = user.guardar();
                if (guardado) {
                    JOptionPane.showMessageDialog(null, "se ha registrado con exito");
                } else {
                    JOptionPane.showMessageDialog(null, "NO se ha podido registrar");
                }
            }
        }

        if (e.getSource().equals(login.jbOrganizacion)) {
            login.remove(login.jlSubTitulo);
            login.remove(login.jbContraseña);
            login.remove(login.jpContraseña);
            login.remove(login.verContraseña);
            login.remove(login.jbCorreo);
            login.remove(login.jtCorreo);
            login.remove(login.jlOrganizacion);
            login.remove(login.jbOrganizacion);
            login.remove(login.jbSalir);
            login.remove(login.jbRegistrarse);
            login.remove(login.jbIniciar_sesion);

            login.add(login.jlSubTitulo3);
            login.add(login.jbVolverOrg);
            login.add(login.jlLlave_acceso);
            login.add(login.jtLlave_acceso);
            login.add(login.jbIniciarOrg);

            login.revalidate();
            login.repaint();
        }
        if (e.getSource().equals(login.jbIniciarOrg)) {

            boolean existe = false;

            Organizacion org = new Organizacion();
            List<Organizacion> resultados = org.selectOrganizaciones();
            for (Organizacion organizacion : resultados) {
                if (organizacion.getID() == Long.parseLong(login.jtLlave_acceso.getText())) {
                    existe = true;
                    org = organizacion;
                }
            }
            if (existe) {
                login.setVisible(false);
                Vista_Organizacion vista_org = new Vista_Organizacion(login, org);
                login.dispose();

            } else {
                JOptionPane.showMessageDialog(null, "Correo no registrado");
            }
        }

        if (e.getSource().equals(login.jbVolverUser)) {
            login.remove(login.jlSubTitulo2);
            login.remove(login.jbCorreo);
            login.remove(login.jtCorreo);
            login.remove(login.jbContraseña);
            login.remove(login.jpContraseña);
            login.remove(login.jbNombre);
            login.remove(login.jtApellido);
            login.remove(login.jbApellido);
            login.remove(login.jtNombre);
            login.remove(login.jbRegistrar);
            login.remove(login.jbVolverUser);
            login.Start();
        }
        if (e.getSource().equals(login.jbVolverOrg)) {
            login.remove(login.jlSubTitulo3);
            login.remove(login.jlLlave_acceso);
            login.remove(login.jtLlave_acceso);
            login.remove(login.jbIniciarOrg);
            login.remove(login.jbVolverOrg);
            login.Start();
        }

        if (e.getSource().equals(login.jbSalir)) {
            eventoSalir();
        }
    }

    @Override
    public void windowOpened(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana se abre
    }

    @Override
    public void windowClosing(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana se está cerrando
        eventoSalir(); // Cierra aplicación al intentar cerrar ventana
    }

    @Override
    public void windowClosed(java.awt.event.WindowEvent e) {
        // Método llamado después de que la ventana se ha cerrado
    }

    @Override
    public void windowIconified(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana se minimiza
    }

    @Override
    public void windowDeiconified(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana se restaura desde el estado minimizado
    }

    @Override
    public void windowActivated(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana gana el foco
    }

    @Override
    public void windowDeactivated(java.awt.event.WindowEvent e) {
        // Método llamado cuando la ventana pierde el foco
    }

    /**
     * Cierra la aplicación completamente
     */
    public void eventoSalir() {
        login.setVisible(false);
        login.dispose(); //Libera Recursos
    }
}
