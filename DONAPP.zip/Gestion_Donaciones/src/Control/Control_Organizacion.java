package Control;

import Modelo.Campaña;
import Modelo.Meta;
import Vista.Vista_Login;
import Vista.Vista_Organizacion;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/**
 * Controlador principal para la interfaz de organizaciones.
 * Gestiona:
 *   - Operaciones CRUD para campañas (crear/editar/ver)
 *   - Generación de gráficos estadísticos de recaudación
 *   - Validación de fechas y metas en campañas
 *   - Navegación entre diferentes vistas
 * 
 * Coordina las operaciones entre Vista_Organizacion y los modelos Campaña/Meta.
 */
public class Control_Organizacion implements ActionListener {

    private Vista_Organizacion vista_org; // Vista asociada

    private String nombreCampaña; // Almacena nombre temporal para edición

    public Control_Organizacion(Vista_Organizacion vista_org) {
        this.vista_org = vista_org; // Vincula vista al controlador
    }

    /**
     * Maneja todos los eventos de la interfaz organizacional:
     *   - Gestión de campañas (crear/editar/visualizar)
     *   - Generación de gráficos de recaudación
     *   - Validación de datos en formularios
     *   - Navegación entre vistas
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {

        // Ver las Campañas relacionadas
        if (e.getSource() == vista_org.jbCampañas) {

            vista_org.remove(vista_org.jlCampañas);
            vista_org.remove(vista_org.jbCampañas);
            vista_org.remove(vista_org.jlAñadirCampaña);
            vista_org.remove(vista_org.jbAñadirCampaña);
            vista_org.remove(vista_org.jlGenerarGraficas);
            vista_org.remove(vista_org.jbGenerarGraficas);
            vista_org.remove(vista_org.jlEditarCampaña);
            vista_org.remove(vista_org.jbEditarCampaña);
            vista_org.remove(vista_org.jbVolver);

            String[] fila = new String[5];
            Campaña campaña = new Campaña();
            List<Campaña> resultados = campaña.selectCampañasOrganizacion(vista_org.organizacion.getID());
            for (Campaña resultado : resultados) {
                fila[0] = Long.toString(resultado.getID());
                fila[1] = resultado.getNombre();
                fila[2] = resultado.getFecha_inicio();
                fila[3] = resultado.getFecha_fin();

                Meta meta = new Meta();
                meta = meta.selectMetaCampaña(resultado.getID());
                fila[4] = Long.toString(meta.getMeta_propuesta());

                vista_org.dt.addRow(fila);
            }

            vista_org.jsCampañas.setBounds(15, 160, 750, 250);
            vista_org.add(vista_org.jbVolverOrg);
            vista_org.add(vista_org.jsCampañas);

            vista_org.revalidate();
            vista_org.repaint();
        }

        // Añadir una nueva Campaña
        if (e.getSource() == vista_org.jbAñadirCampaña) {
            vista_org.remove(vista_org.jlCampañas);
            vista_org.remove(vista_org.jbCampañas);
            vista_org.remove(vista_org.jlAñadirCampaña);
            vista_org.remove(vista_org.jbAñadirCampaña);
            vista_org.remove(vista_org.jlGenerarGraficas);
            vista_org.remove(vista_org.jbGenerarGraficas);
            vista_org.remove(vista_org.jlEditarCampaña);
            vista_org.remove(vista_org.jbEditarCampaña);
            vista_org.remove(vista_org.jbVolver);

            vista_org.add(vista_org.jlNombreCampaña);
            vista_org.add(vista_org.jtNombreCampaña);
            vista_org.add(vista_org.jlDescripcionCampaña);
            vista_org.add(vista_org.jsDescripcion);
            vista_org.add(vista_org.jlFechaInicio);
            vista_org.add(vista_org.spFechaInicio);
            vista_org.add(vista_org.jlFechaFin);
            vista_org.add(vista_org.spFechaFin);
            vista_org.add(vista_org.jlMeta);
            vista_org.add(vista_org.jtMeta);
            vista_org.add(vista_org.jbCrearCampaña);
            vista_org.add(vista_org.jbVolverOrg);

            vista_org.revalidate();
            vista_org.repaint();
        }

        if (e.getSource() == vista_org.jbCrearCampaña) {
            // Obtener los datos ingresados por el usuario
            String nombre = vista_org.jtNombreCampaña.getText();
            String descripcion = vista_org.taDescripcionCampaña.getText();
            String fechaInicio = ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaInicio.getEditor()).getTextField().getText();
            String fechaFin = ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaFin.getEditor()).getTextField().getText();
            Long meta = Long.parseLong(vista_org.jtMeta.getText());

            // Validar que la fecha de inicio sea anterior a la fecha de fin
            if (fechaInicio.compareTo(fechaFin) > 0) {
                JOptionPane.showMessageDialog(null, "La fecha de inicio debe ser anterior a la fecha de fin.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } else {
                // Validar que la meta sea un número positivo
                if (meta <= 0) {
                    JOptionPane.showMessageDialog(null, "La meta debe ser un número positivo.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                } else {
                    // Validar que los campos no estén vacíos
                    if (nombre.isEmpty() || descripcion.isEmpty() || fechaInicio.isEmpty() || fechaFin.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    } else {
                        // Crear una nueva campaña
                        Campaña nuevaCampaña = new Campaña();
                        nuevaCampaña.setNombre(nombre);
                        nuevaCampaña.setDescripcion(descripcion);
                        nuevaCampaña.setFecha_inicio(fechaInicio);
                        nuevaCampaña.setFecha_fin(fechaFin);
                        nuevaCampaña.setOrganizacion(vista_org.organizacion);

                        // Guardar la campaña en la base de datos
                        boolean guardadoCamp = nuevaCampaña.guardar();
                        if (guardadoCamp) {
                            Campaña campañaGuardada = nuevaCampaña.selectCampañaNombre(nuevaCampaña.getNombre());

                            // Guardar la meta en la base de datos
                            Meta nuevaMeta = new Meta(meta, campañaGuardada);
                            boolean guardadoMeta = nuevaMeta.guardar();
                            if (guardadoMeta) {
                                JOptionPane.showMessageDialog(null, "Campaña creada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                evento_volver_org(); // Volver a la vista principal de la organización
                            } else {
                                JOptionPane.showMessageDialog(null, "Error al crear la Meta.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al crear la campaña.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        }

        // Editar una Campaña
        if (e.getSource() == vista_org.jbEditarCampaña) {
            vista_org.remove(vista_org.jlCampañas);
            vista_org.remove(vista_org.jbCampañas);
            vista_org.remove(vista_org.jlAñadirCampaña);
            vista_org.remove(vista_org.jbAñadirCampaña);
            vista_org.remove(vista_org.jlGenerarGraficas);
            vista_org.remove(vista_org.jbGenerarGraficas);
            vista_org.remove(vista_org.jlEditarCampaña);
            vista_org.remove(vista_org.jbEditarCampaña);
            vista_org.remove(vista_org.jbVolver);

            vista_org.add(vista_org.jlNombreCampaña);
            vista_org.add(vista_org.jtNombreCampaña);
            vista_org.add(vista_org.jbBuscarCampaña);
            vista_org.add(vista_org.jbVolverOrg);

            vista_org.revalidate();
            vista_org.repaint();
        }
        if (e.getSource() == vista_org.jbBuscarCampaña) {
            if (vista_org.jtNombreCampaña.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese el nombre de la campaña a editar.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } else {
                Campaña campaña = new Campaña();
                campaña = campaña.selectCampañaNombre(vista_org.jtNombreCampaña.getText());
                if (campaña == null) {
                    JOptionPane.showMessageDialog(null, "No se encontró la campaña con el nombre ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                } else {
                    nombreCampaña = campaña.getNombre();

                    vista_org.remove(vista_org.jbBuscarCampaña);

                    vista_org.add(vista_org.jlDescripcionCampaña);
                    vista_org.add(vista_org.jsDescripcion);
                    vista_org.add(vista_org.jlFechaInicio);
                    vista_org.add(vista_org.spFechaInicio);
                    vista_org.add(vista_org.jlFechaFin);
                    vista_org.add(vista_org.spFechaFin);
                    vista_org.add(vista_org.jlMeta);
                    vista_org.add(vista_org.jtMeta);
                    vista_org.add(vista_org.jbEditCampaña);

                    // Cargar los datos de la campaña en los campos correspondientes
                    vista_org.taDescripcionCampaña.setText(campaña.getDescripcion());
                    ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaInicio.getEditor()).getTextField().setText(campaña.getFecha_inicio());
                    ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaFin.getEditor()).getTextField().setText(campaña.getFecha_fin());

                    Meta meta = new Meta();
                    meta = meta.selectMetaCampaña(campaña.getID());
                    vista_org.jtMeta.setText(Long.toString(meta.getMeta_propuesta()));

                    vista_org.revalidate();
                    vista_org.repaint();
                }
            }
        }

        if (e.getSource() == vista_org.jbEditCampaña) {
            // Obtener los datos ingresados por el usuario
            String nombre = vista_org.jtNombreCampaña.getText();
            String descripcion = vista_org.taDescripcionCampaña.getText();
            String fechaInicio = ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaInicio.getEditor()).getTextField().getText();
            String fechaFin = ((javax.swing.JSpinner.DefaultEditor) vista_org.spFechaFin.getEditor()).getTextField().getText();
            Long meta = Long.parseLong(vista_org.jtMeta.getText());

            // Validar que la fecha de inicio sea anterior a la fecha de fin
            if (fechaInicio.compareTo(fechaFin) > 0) {
                JOptionPane.showMessageDialog(null, "La fecha de inicio debe ser anterior a la fecha de fin.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Validar que la meta sea un número positivo
                if (meta <= 0) {
                    JOptionPane.showMessageDialog(null, "La meta debe ser un número positivo.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Validar que los campos no estén vacíos
                    if (nombre.isEmpty() || descripcion.isEmpty() || fechaInicio.isEmpty() || fechaFin.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        // Obtener la campaña seleccionada
                        Campaña campaña = new Campaña();
                        campaña = campaña.selectCampañaNombre(nombreCampaña);
                        if (campaña == null) {
                            JOptionPane.showMessageDialog(null, "No se encontró la campaña con el nombre ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            // Editar la campaña
                            Campaña nuevaCampaña = new Campaña();
                            nuevaCampaña.setNombre(nombre);
                            nuevaCampaña.setDescripcion(descripcion);
                            nuevaCampaña.setFecha_inicio(fechaInicio);
                            nuevaCampaña.setFecha_fin(fechaFin);
                            nuevaCampaña.setOrganizacion(vista_org.organizacion);

                            // Actualizar la campaña en la base de datos
                            boolean guardadoCamp = nuevaCampaña.actualizar(campaña.getID());
                            if (guardadoCamp) {
                                Campaña campañaGuardada = nuevaCampaña.selectCampañaNombre(nuevaCampaña.getNombre());

                                // Actualizar la meta en la base de datos
                                Meta nuevaMeta = new Meta();
                                nuevaMeta = nuevaMeta.selectMetaCampaña(campañaGuardada.getID());
                                nuevaMeta.setMeta_propuesta(meta);
                                boolean guardadoMeta = nuevaMeta.actualizar(nuevaMeta.getID());
                                if (guardadoMeta) {
                                    JOptionPane.showMessageDialog(null, "Campaña editada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                    evento_volver_org(); // Volver a la vista principal de la organización
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Ver Graficas
        if (e.getSource() == vista_org.jbGenerarGraficas) {
            
            vista_org.remove(vista_org.jlCampañas);
            vista_org.remove(vista_org.jbCampañas);
            vista_org.remove(vista_org.jlAñadirCampaña);
            vista_org.remove(vista_org.jbAñadirCampaña);
            vista_org.remove(vista_org.jlGenerarGraficas);
            vista_org.remove(vista_org.jbGenerarGraficas);
            vista_org.remove(vista_org.jlEditarCampaña);
            vista_org.remove(vista_org.jbEditarCampaña);
            vista_org.remove(vista_org.jbVolver);

            String[] fila = new String[5];
            Campaña campaña = new Campaña();
            List<Campaña> resultados = campaña.selectCampañasOrganizacion(vista_org.organizacion.getID());
            for (Campaña resultado : resultados) {
                fila[0] = Long.toString(resultado.getID());
                fila[1] = resultado.getNombre();
                fila[2] = resultado.getFecha_inicio();
                fila[3] = resultado.getFecha_fin();

                Meta meta = new Meta();
                meta = meta.selectMetaCampaña(resultado.getID());
                fila[4] = Long.toString(meta.getMeta_propuesta());

                vista_org.dt.addRow(fila);
            }

            vista_org.jsCampañas.setBounds(15, 120, 500, 250);
            vista_org.add(vista_org.jbVolverOrg);
            vista_org.add(vista_org.jsCampañas);
            vista_org.add(vista_org.jlCampañaGrafica);
            vista_org.add(vista_org.jtCampañaGrafica);
            vista_org.add(vista_org.jbCampañaGrafica);

            vista_org.revalidate();
            vista_org.repaint();
        }
        
        if (e.getSource() == vista_org.jbCampañaGrafica) {
            if (vista_org.jtCampañaGrafica.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese el nombre de la campaña.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } else {
                Campaña campaña = new Campaña();
                campaña = campaña.selectCampañaNombre(vista_org.jtCampañaGrafica.getText());
                if (campaña == null) {
                    JOptionPane.showMessageDialog(null, "No se encontró la campaña con el nombre ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                } else {
                    Meta meta = new Meta();
                    meta = meta.selectMetaCampaña(campaña.getID());
                    
                    long recaudado = meta.getMonto_acumulado();
                    long restante;
                    if(meta.getMonto_acumulado()>meta.getMeta_propuesta())
                        restante = 0;
                    else
                        restante = meta.getMeta_propuesta() - meta.getMonto_acumulado();
                    
                    vista_org.remove(vista_org.jsCampañas);
                    vista_org.remove(vista_org.jlCampañaGrafica);
                    vista_org.remove(vista_org.jtCampañaGrafica);
                    vista_org.remove(vista_org.jbCampañaGrafica);

                    vista_org.data = new DefaultPieDataset();
                    vista_org.data.setValue("Restante", restante);
                    vista_org.data.setValue("Recaudado", recaudado);

                    vista_org.chart = ChartFactory.createPieChart(
                            "Grafica", //Titulo del grafico
                            vista_org.data, //data
                            true, //Leyenda
                            true,
                            false);

                    //pintura
                    vista_org.chart.setBackgroundPaint(Color.white);//Color de fonde de la ventana
                    vista_org.chart.getTitle().setPaint(Color.blue); //Dar color al titulo

                    vista_org.plot = (PiePlot) vista_org.chart.getPlot();
                    vista_org.plot.setLabelBackgroundPaint(Color.cyan);//Color de las etiquetas
                    vista_org.plot.setBackgroundPaint(Color.LIGHT_GRAY); //Color de el fondo del grafico    


                    vista_org.panel = new ChartPanel(vista_org.chart, false);
                    vista_org.panel.setBounds(10, 100, 600, 350);
                    vista_org.add(vista_org.panel);

                    vista_org.revalidate();
                    vista_org.repaint();
                }
            }
        }

        if (e.getSource() == vista_org.jbVolverOrg) {
            evento_volver_org();
        }

        // Cierra sesion y vuelve al login
        if (e.getSource() == vista_org.jbVolver) {
            vista_org.setVisible(false);
            vista_org.dispose();
            vista_org.login = new Vista_Login();
        }
    }
    
    /**
     * Restablece la vista organizacional a su estado inicial
     */
    public void evento_volver_org() {
        vista_org.removeAll();
        vista_org.setVisible(false);
        vista_org.dispose();
        vista_org = new Vista_Organizacion(vista_org.login, vista_org.organizacion);
        // Recarga la vista organizacional
    }
}
