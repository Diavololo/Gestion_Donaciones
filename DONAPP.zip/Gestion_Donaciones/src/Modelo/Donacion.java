package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Donacion extends ConexionBD {

    private Long id;
    private Long monto;
    private String fecha;
    private String metodo_pago;
    private Usuario usuario;
    private Campaña campaña;

    // Constructores
    public Donacion() {
    }

    public Donacion(Long monto, String fecha, String metodo_pago, Usuario usuario, Campaña campaña) {
        this.monto = monto;
        this.fecha = fecha;
        this.metodo_pago = metodo_pago;
        this.usuario = usuario;
        this.campaña = campaña;
    }

    public Donacion(Long id, Long monto, String fecha, String metodo_pago, Usuario usuario, Campaña campaña) {
        this.id = id;
        this.monto = monto;
        this.fecha = fecha;
        this.metodo_pago = metodo_pago;
        this.usuario = usuario;
        this.campaña = campaña;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public Long getMonto() {
        return monto;
    }

    public String getFecha() {
        return fecha;
    }

    public String getMetodo_pago() {
        return metodo_pago;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Campaña getCampaña() {
        return campaña;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setMonto(Long monto) {
        this.monto = monto;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setMetodo_pago(String metodo_pago) {
        this.metodo_pago = metodo_pago;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setCampaña(Campaña campaña) {
        this.campaña = campaña;
    }

    // Guardar donación en la base de datos
    public boolean guardar() {
        try {
            conectarMySQL();
            String sql = "INSERT INTO donacion (Monto, Fecha, Metodo_Pago, ID_Usuario, ID_Campaña) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, getMonto());
            ps.setString(2, getFecha());
            ps.setString(3, getMetodo_pago());
            ps.setLong(4, getUsuario().getID());
            ps.setLong(5, getCampaña().getID());
            ps.executeUpdate();
            ps.close();

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar donación: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Actualizar donación en la base de datos
    public boolean actualizar(long id) {
        try {
            conectarMySQL();
            String sql = "UPDATE donacion SET Monto = ?, Fecha = ?, Metodo_Pago = ?, ID_Usuario = ?, ID_Campaña = ? WHERE ID_Donacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, getMonto());
            ps.setString(2, getFecha());
            ps.setString(3, getMetodo_pago());
            ps.setLong(4, getUsuario().getID());
            ps.setLong(5, getCampaña().getID());
            ps.setLong(6, id);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar donación: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar donación de la base de datos
    public boolean eliminar(long id) {
        try {
            conectarMySQL();
            String sql = "DELETE FROM donacion WHERE ID_Donacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar donación: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Seleccionar una donación por ID
    public Donacion selectDonacionID(long id) {
        Donacion resultado = null;
        try {
            conectarMySQL();
            String sql = "SELECT * FROM donacion WHERE ID_Donacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                resultado = new Donacion();
                resultado.setId(rs.getLong("ID_Donacion"));
                resultado.setMonto(rs.getLong("Monto"));
                resultado.setFecha(rs.getString("Fecha"));
                resultado.setMetodo_pago(rs.getString("Metodo_Pago"));

                Usuario CorreoUsuario = new Usuario();
                resultado.setUsuario(CorreoUsuario.selectUsuarioID(rs.getLong("ID_Usuario")));

                Campaña idCampaña = new Campaña();
                resultado.setCampaña(idCampaña.selectCampañaID(rs.getLong("ID_Campaña")));
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar donación: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultado;
    }

    // Seleccionar todas las donaciones de un Usuario
    public List<Donacion> selectDonacionesUsuario(Usuario usuario) {
        List<Donacion> resultados = new ArrayList<>();
        Long idUsuario = usuario.getID();
        try {
            conectarMySQL();
            String sql = "SELECT * FROM donacion WHERE ID_Usuario = ?";
            stmt = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, idUsuario);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Donacion donacion = new Donacion();
                donacion.setId(rs.getLong("ID_Donacion"));
                donacion.setMonto(rs.getLong("Monto"));
                donacion.setFecha(rs.getString("Fecha"));
                donacion.setMetodo_pago(rs.getString("Metodo_Pago"));

                Usuario user = new Usuario();
                donacion.setUsuario(user.selectUsuarioID(rs.getLong("ID_Usuario")));

                Campaña idCampaña = new Campaña();
                donacion.setCampaña(idCampaña.selectCampañaID(rs.getLong("ID_Campaña")));

                resultados.add(donacion);
            }
            rs.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar donaciones: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultados;
    }

    // Seleccionar todas las donaciones
    public List<Donacion> selectDonaciones() {
        List<Donacion> resultados = new ArrayList<>();
        try {
            conectarMySQL();
            String sql = "SELECT * FROM donacion";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Donacion donacion = new Donacion();
                donacion.setId(rs.getLong("ID_Donacion"));
                donacion.setMonto(rs.getLong("Monto"));
                donacion.setFecha(rs.getString("Fecha"));
                donacion.setMetodo_pago(rs.getString("Metodo_Pago"));

                Usuario CorreoUsuario = new Usuario();
                donacion.setUsuario(CorreoUsuario.selectUsuarioID(rs.getLong("ID_Usuario")));

                Campaña idCampaña = new Campaña();
                donacion.setCampaña(idCampaña.selectCampañaID(rs.getLong("ID_Campaña")));

                resultados.add(donacion);
            }
            rs.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar donaciones: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultados;
    }
}
