package Modelo;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * Clase para gestionar la conexión con la base de datos MySQL.
 * Proporciona métodos para:
 *   - Establecer conexión con la BD
 *   - Cerrar conexión con la BD
 *   - Manejar errores de conexión
 * 
 * Utiliza parámetros configurables para host, nombre de BD, usuario y contraseña.
 */
public class ConexionBD {
    
    public static Connection conn; // Objeto para la conexion
    public static Statement stmt;// Objeto para ejecutar la consulta
    public String bd = "gestion_donaciones_bd";
    public String login = "root";
    public String password = "";
    public String host = "127.0.0.1";
    
    /**
     * Establece conexión con la base de datos MySQL.
     * Configuración por defecto:
     *   - Driver: com.mysql.cj.jdbc.Driver
     *   - Puerto: 3306
     *   - URL: jdbc:mysql://localhost:3306/gestion_donaciones_bd
     * 
     * @return true si la conexión fue exitosa, false en caso de error
     */
    public boolean conectarMySQL(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + bd, login, password);
            stmt = conn.createStatement();
            System.out.println("Conectado...");
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Error en la conexión a la BD "+ sqle.getMessage());
            return false;
        }
        return true;
    }

    /**
     * Cierra la conexión con la base de datos.
     * Libera recursos de Statement y Connection.
     * 
     * @return true si la desconexión fue exitosa, false en caso de error
     */
    public boolean desconectar() {
        try {
            if(stmt != null) stmt.close();
            if(conn != null) conn.close();
            
            System.out.println("Desconectado.");
            
            return true;
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Error al tratar de desconectarse con la base de datos 'ferreteriabd' "+ sqle.getMessage());
            return false;
        }
    }
}
