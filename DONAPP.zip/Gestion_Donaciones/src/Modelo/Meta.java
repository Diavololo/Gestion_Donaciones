package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Meta extends ConexionBD {

    private long ID;
    private long meta_propuesta;
    private long monto_acumulado;
    private Campaña campaña;

    // Constructores
    public Meta() {
    }

    public Meta(long meta_propuesta, Campaña campaña) {
        this.meta_propuesta = meta_propuesta;
        this.campaña = campaña;
    }

    public Meta(long ID, long meta_propuesta, long monto_acumulado, Campaña campaña) {
        this.ID = ID;
        this.meta_propuesta = meta_propuesta;
        this.monto_acumulado = monto_acumulado;
        this.campaña = campaña;
    }

    // Getters
    public long getID() {
        return ID;
    }

    public long getMeta_propuesta() {
        return meta_propuesta;
    }

    public long getMonto_acumulado() {
        return monto_acumulado;
    }

    public Campaña getCampaña() {
        return campaña;
    }

    // Setters
    public void setID(long ID) {
        this.ID = ID;
    }

    public void setMeta_propuesta(long meta_propuesta) {
        this.meta_propuesta = meta_propuesta;
    }

    public void setMonto_acumulado(long monto_acumulado) {
        this.monto_acumulado = monto_acumulado;
    }

    public void setCampaña(Campaña campaña) {
        this.campaña = campaña;
    }

    // Guardar meta en la base de datos
    public boolean guardar() {
        try {
            conectarMySQL();
            String sql = "INSERT INTO meta (Meta_Propuesta, ID_Campaña) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, getMeta_propuesta());
            ps.setLong(2, getCampaña().getID());
            ps.executeUpdate();
            ps.close();

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar meta: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Actualizar meta en la base de datos
    public boolean actualizar(long id) {
        try {
            conectarMySQL();
            String sql = "UPDATE meta SET Meta_Propuesta = ?, Monto_Acomulado = ?, ID_Campaña = ? WHERE ID_Meta = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, getMeta_propuesta());
            ps.setLong(2, getMonto_acumulado());
            ps.setLong(3, getCampaña().getID());
            ps.setLong(4, id);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar meta: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Actualizar acomulado
    public boolean actualizarAcomulado(long id_campaña, long monto) {
        try {
            conectarMySQL();

            // Obtener el monto acumulado actual
            String sqlSelect = "SELECT Monto_Acomulado FROM meta WHERE ID_Campaña = ?";
            PreparedStatement psSelect = conn.prepareStatement(sqlSelect);
            psSelect.setLong(1, id_campaña);
            ResultSet rs = psSelect.executeQuery();

            long montoActual = 0;
            if (rs.next()) {
                montoActual = rs.getLong("Monto_Acomulado");
            }
            rs.close();
            psSelect.close();

            // Sumar el nuevo monto al acumulado actual
            long nuevoMonto = montoActual + monto;

            // Actualizar el monto acumulado en la base de datos
            String sqlUpdate = "UPDATE meta SET Monto_Acomulado = ? WHERE ID_Campaña = ?";
            PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
            psUpdate.setLong(1, nuevoMonto);
            psUpdate.setLong(2, id_campaña);
            psUpdate.executeUpdate();
            psUpdate.close();

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el monto acumulado: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar meta de la base de datos
    public boolean eliminar(long id) {
        try {
            conectarMySQL();
            String sql = "DELETE FROM meta WHERE ID_Meta = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar meta: " + e.getMessage());
            return false;
        } finally {
            desconectar();
        }
    }

    // Seleccionar una meta por ID
    public Meta selectMetaID(long id) {
        Meta resultado = null;
        try {
            conectarMySQL();
            String sql = "SELECT * FROM meta WHERE ID_Meta = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                resultado = new Meta();
                resultado.setID(rs.getLong("ID_Meta"));
                resultado.setMeta_propuesta(rs.getLong("Meta_Propuesta"));
                resultado.setMonto_acumulado(rs.getLong("Monto_Acomulado"));

                Campaña campaña = new Campaña();
                resultado.setCampaña(campaña.selectCampañaID(rs.getLong("ID_Campaña")));
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar meta: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultado;
    }

    // Seleccionar una meta por Campaña
    public Meta selectMetaCampaña(long id_campaña) {
        Meta resultado = null;
        try {
            conectarMySQL();
            String sql = "SELECT * FROM meta WHERE ID_Campaña = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id_campaña);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                resultado = new Meta();
                resultado.setID(rs.getLong("ID_Meta"));
                resultado.setMeta_propuesta(rs.getLong("Meta_Propuesta"));
                resultado.setMonto_acumulado(rs.getLong("Monto_Acomulado"));

                Campaña campaña = new Campaña();
                resultado.setCampaña(campaña.selectCampañaID(rs.getLong("ID_Campaña")));
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar meta: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultado;
    }

    // Seleccionar todas las metas
    public List<Meta> selectMetas() {
        List<Meta> resultados = new ArrayList<>();
        try {
            conectarMySQL();
            String sql = "SELECT * FROM meta";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Meta meta = new Meta();
                meta.setID(rs.getLong("ID_Meta"));
                meta.setMeta_propuesta(rs.getLong("Meta_Propuesta"));
                meta.setMonto_acumulado(rs.getLong("Monto_Acomulado"));

                Campaña campaña = new Campaña();
                meta.setCampaña(campaña.selectCampañaID(rs.getLong("ID_Campaña")));

                resultados.add(meta);
            }
            rs.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar metas: " + e.getMessage());
        } finally {
            desconectar();
        }
        return resultados;
    }
}
