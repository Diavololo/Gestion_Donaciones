package gestion_donaciones;

import Vista.Vista_Login;

public class Main {

    public Main() {
        Vista_Login vista = new Vista_Login();
    }

    public static void main(String[] args) {
        Main start = new Main();
    }
}
