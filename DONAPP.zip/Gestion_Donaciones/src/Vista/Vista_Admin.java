package Vista;

import Control.Control_Admin;
import javax.swing.*;
import java.awt.*;

import javax.swing.table.DefaultTableModel;

/**
 * Ventana de administración para gestionar organizaciones y usuarios.
 * Permite:
 *   - Gestionar organizaciones (añadir/editar/eliminar/ver)
 *   - Gestionar usuarios (añadir/editar/eliminar/ver)
 *   - Acceder a futuras funcionalidades de campañas
 * 
 * Diseñada con fondo personalizado y componentes Swing para operaciones CRUD.
 * Coordina con la clase Control_Admin para manejar eventos.
 */
public class Vista_Admin extends JFrame {

    // --------------------------
    // SECCIÓN DE ORGANIZACIONES
    // --------------------------
    public JButton jbMenuOrganizacion, jbAñadirOrg, jbEliminarOrg, jbEditarOrg, jbVerOrg, jbVolverOrg, jbBuscarVerOrg, jbBuscarEditarOrg, jbAddOrg, jbDeleteOrg, jbEditOrg;
    public JTextField jtLlave, jtNombre, jtContacto, jtBuscarVer;
    public JLabel jlAñadirOrg, jlEditarOrg, jlEliminarOrg, jlVerOrg, jlLlave, jlNombre, jlContacto, jlBuscarVerOrg;

    // ---------------------
    // SECCIÓN DE USUARIOS
    // ---------------------
    public JComboBox<String> jcTipoUsuario;
    public JButton jbMenuUsuarios, jbAñadirUsuario, jbEliminarUsuario, jbEditarUsuario, jbVerUsuario, jbVolverUsuario, jbBuscarVerUsuario, jbBuscarEditarUsuario, jbAddUsuario, jbDeleteUsuario, jbEditUsuario;
    public JTextField jtNombreUsuario, jtApellidoUsuario, jtCorreoUsuario, jtContraseñaUsuario, jtBuscarVerUsuario;
    public JLabel jlAñadirUsuario, jlEditarUsuario, jlEliminarUsuario, jlVerUsuario, jlNombreUsuario, jlApellidoUsuario, jlCorreoUsuario, jlContraseñaUsuario, jlBuscarVerUsuario, jlTipoUsuario;

    // --------------------------
    // COMPONENTES GENERALES
    // --------------------------
    public JButton jbVolver, jbMenuCampañas;
    public JLabel jlTitulo, jlSubTitulo, jlMensajes;
    public DefaultTableModel dt;
    public JTable table;
    public JScrollPane js;
    public Vista_Login login;
    public Control_Admin ctrl_admin;

    /**
     * Constructor principal.
     * Configura:
     *   - Título: "Gestor de donaciones"
     *   - Tamaño fijo (800x520)
     *   - Centrado en pantalla
     *   - Panel de fondo personalizado (FondoPanel)
     *   - Inicializa menú principal
     * 
     * @param login Referencia a la ventana de login para posibles retornos
     */
    public Vista_Admin(Vista_Login login) {
        super("Gestor de donaciones");
        ctrl_admin = new Control_Admin(this);
        this.login = login;
        setSize(800, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setContentPane(new FondoPanel()); // Fondo personalizado
        setLayout(null); // Layout manual

        Menu_Principal(); // Inicializa interfaz principal
        setVisible(true);
    }

    /**
     * Configura el menú principal de administración:
     *   - Botones para gestionar organizaciones, usuarios y campañas
     *   - Botón para volver al login
     */
    public void Menu_Principal() {
        jlTitulo = new JLabel("Administrador");
        jlTitulo.setBounds(0, 5, 800, 50);
        jlTitulo.setOpaque(true);
        jlTitulo.setBackground(Color.LIGHT_GRAY);
        jlTitulo.setForeground(Color.DARK_GRAY);
        jlTitulo.setFont(new Font("Tahoma", Font.BOLD, 40));
        add(jlTitulo);

        jbMenuOrganizacion = new JButton("Gestion de Organizacion");
        jbMenuOrganizacion.setBounds(15, 70, 190, 30);
        jbMenuOrganizacion.addActionListener(ctrl_admin);
        add(jbMenuOrganizacion);

        jbMenuUsuarios = new JButton("Gestion de Usuarios");
        jbMenuUsuarios.setBounds(15, 110, 190, 30);
        jbMenuUsuarios.addActionListener(ctrl_admin);
        add(jbMenuUsuarios);

        jbMenuCampañas = new JButton("Gestion de Campañas");
        jbMenuCampañas.setBounds(15, 150, 190, 30);
        add(jbMenuCampañas);
        jbMenuCampañas.setVisible(false);

        jbVolver = new JButton("Volver");
        jbVolver.setBounds(650, 440, 120, 30);
        jbVolver.addActionListener(ctrl_admin);
        add(jbVolver);

        revalidate();
        repaint();
    }

    /**
     * Configura la interfaz de gestión de organizaciones:
     *   - Opciones CRUD para organizaciones
     *   - Campos para llave, nombre y contacto
     *   - Tabla para visualizar registros
     *   - Botones de búsqueda específica
     */
    public void Menu_Organizacion() {
        jlSubTitulo = new JLabel("Gestion De Organizaciones");
        jlSubTitulo.setBounds(0, 60, 800, 40);
        jlSubTitulo.setOpaque(true);
        jlSubTitulo.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo.setForeground(Color.DARK_GRAY);
        jlSubTitulo.setFont(new Font("Tahoma", Font.BOLD, 25));
        add(jlSubTitulo);

        jlAñadirOrg = new JLabel("Añadir nueva organizacion:");
        jlAñadirOrg.setBounds(15, 120, 190, 30);
        add(jlAñadirOrg);
        jbAñadirOrg = new JButton("Añadir");
        jbAñadirOrg.setBounds(180, 120, 100, 30);
        jbAñadirOrg.addActionListener(ctrl_admin);
        add(jbAñadirOrg);

        jlEditarOrg = new JLabel("Editar Organizacion:");
        jlEditarOrg.setBounds(44, 160, 190, 30);
        add(jlEditarOrg);
        jbEditarOrg = new JButton("Editar");
        jbEditarOrg.setBounds(180, 160, 100, 30);
        jbEditarOrg.addActionListener(ctrl_admin);
        add(jbEditarOrg);

        jlEliminarOrg = new JLabel("Eliminar organizacion:");
        jlEliminarOrg.setBounds(44, 200, 190, 30);
        add(jlEliminarOrg);
        jbEliminarOrg = new JButton("Eliminar");
        jbEliminarOrg.setBounds(180, 200, 100, 30);
        jbEliminarOrg.addActionListener(ctrl_admin);
        add(jbEliminarOrg);

        jlVerOrg = new JLabel("Ver las organizaciones:");
        jlVerOrg.setBounds(34, 260, 190, 30);
        add(jlVerOrg);
        jbVerOrg = new JButton("Ver");
        jbVerOrg.setBounds(180, 260, 100, 30);
        jbVerOrg.addActionListener(ctrl_admin);
        add(jbVerOrg);

        jbVolverOrg = new JButton("Volver");
        jbVolverOrg.setBounds(650, 440, 120, 30);
        jbVolverOrg.addActionListener(ctrl_admin);
        add(jbVolverOrg);
        
        //Opciones para añadir, editar y eliminar organizaciones,
        jlLlave = new JLabel("Llave de acceso(numerico):");
        jlLlave.setBounds(20, 120, 250, 30);
        jtLlave = new JTextField();
        jtLlave.setBounds(195, 120, 80, 30);

        jlNombre = new JLabel("Nombre de la Organizacion:");
        jlNombre.setBounds(20, 160, 250, 30);
        jtNombre = new JTextField();
        jtNombre.setBounds(195, 160, 160, 30);

        jlContacto = new JLabel("Contacto(Correo Electronico):");
        jlContacto.setBounds(20, 200, 250, 30);
        jtContacto = new JTextField();
        jtContacto.setBounds(195, 200, 160, 30);

        jbAddOrg = new JButton("Añadir");
        jbAddOrg.setBounds(20, 260, 100, 30);
        jbAddOrg.addActionListener(ctrl_admin);

        jbDeleteOrg = new JButton("Eliminar");
        jbDeleteOrg.setBounds(20, 180, 100, 30);
        jbDeleteOrg.addActionListener(ctrl_admin);

        jbEditOrg = new JButton("Editar");
        jbEditOrg.setBounds(20, 260, 100, 30);
        jbEditOrg.addActionListener(ctrl_admin);

        jbBuscarEditarOrg = new JButton("Buscar");
        jbBuscarEditarOrg.setBounds(300, 120, 100, 30);
        jbBuscarEditarOrg.addActionListener(ctrl_admin);

        //Opciones para ver las organizaciones
        jlBuscarVerOrg = new JLabel("Buscar por Llave:");
        jlBuscarVerOrg.setBounds(540, 120, 250, 30);
        jtBuscarVer = new JTextField();
        jtBuscarVer.setBounds(650, 120, 80, 30);

        jbBuscarVerOrg = new JButton("Buscar");
        jbBuscarVerOrg.setBounds(650, 160, 80, 30);
        jbBuscarVerOrg.addActionListener(ctrl_admin);

        dt = new DefaultTableModel(new Object[]{"Llave", "Nombre", "Contacto"}, 0);
        table = new JTable(dt);
        js = new JScrollPane(table);
        js.setBounds(15, 120, 500, 350);

        revalidate();
        repaint();
    }

    /**
     * Configura la interfaz de gestión de usuarios:
     *   - Opciones CRUD para usuarios
     *   - Campos para nombre, apellido, correo, contraseña y tipo
     *   - Tabla para visualizar registros
     *   - Botones de búsqueda por correo
     */
    public void Menu_Usuarios() {
        jlSubTitulo = new JLabel("Gestion De Usuarios");
        jlSubTitulo.setBounds(0, 60, 800, 40);
        jlSubTitulo.setOpaque(true);
        jlSubTitulo.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo.setForeground(Color.DARK_GRAY);
        jlSubTitulo.setFont(new Font("Tahoma", Font.BOLD, 25));
        add(jlSubTitulo);

        // Opciones para añadir, editar y eliminar usuarios
        jlAñadirUsuario = new JLabel("Añadir nuevo usuario:");
        jlAñadirUsuario.setBounds(15, 120, 190, 30);
        add(jlAñadirUsuario);
        jbAñadirUsuario = new JButton("Añadir");
        jbAñadirUsuario.setBounds(180, 120, 100, 30);
        jbAñadirUsuario.addActionListener(ctrl_admin);
        add(jbAñadirUsuario);

        jlEditarUsuario = new JLabel("Editar Usuario:");
        jlEditarUsuario.setBounds(44, 160, 190, 30);
        add(jlEditarUsuario);
        jbEditarUsuario = new JButton("Editar");
        jbEditarUsuario.setBounds(180, 160, 100, 30);
        jbEditarUsuario.addActionListener(ctrl_admin);
        add(jbEditarUsuario);

        jlEliminarUsuario = new JLabel("Eliminar usuario:");
        jlEliminarUsuario.setBounds(44, 200, 190, 30);
        add(jlEliminarUsuario);
        jbEliminarUsuario = new JButton("Eliminar");
        jbEliminarUsuario.setBounds(180, 200, 100, 30);
        jbEliminarUsuario.addActionListener(ctrl_admin);
        add(jbEliminarUsuario);

        jlVerUsuario = new JLabel("Ver los usuarios:");
        jlVerUsuario.setBounds(34, 260, 190, 30);
        add(jlVerUsuario);
        jbVerUsuario = new JButton("Ver");
        jbVerUsuario.setBounds(180, 260, 100, 30);
        jbVerUsuario.addActionListener(ctrl_admin);
        add(jbVerUsuario);

        // Campos de texto y botones para gestionar usuarios
        jlNombreUsuario = new JLabel("Nombre:");
        jlNombreUsuario.setBounds(20, 120, 250, 30);
        jtNombreUsuario = new JTextField();
        jtNombreUsuario.setBounds(195, 120, 160, 30);

        jlApellidoUsuario = new JLabel("Apellido:");
        jlApellidoUsuario.setBounds(20, 160, 250, 30);
        jtApellidoUsuario = new JTextField();
        jtApellidoUsuario.setBounds(195, 160, 160, 30);

        jlCorreoUsuario = new JLabel("Correo:");
        jlCorreoUsuario.setBounds(20, 200, 250, 30);
        jtCorreoUsuario = new JTextField();
        jtCorreoUsuario.setBounds(195, 200, 160, 30);

        jlContraseñaUsuario = new JLabel("Contraseña:");
        jlContraseñaUsuario.setBounds(20, 240, 250, 30);
        jtContraseñaUsuario = new JTextField();
        jtContraseñaUsuario.setBounds(195, 240, 160, 30);

        jlTipoUsuario = new JLabel("Tipo de Usuario:");
        jlTipoUsuario.setBounds(20, 280, 250, 30);
        jcTipoUsuario = new JComboBox<>(new String[]{"administrador", "donante"});
        jcTipoUsuario.setBounds(195, 280, 160, 30);

        jbAddUsuario = new JButton("Añadir");
        jbAddUsuario.setBounds(20, 320, 100, 30);
        jbAddUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado

        jbDeleteUsuario = new JButton("Eliminar");
        jbDeleteUsuario.setBounds(360, 200, 100, 30);
        jbDeleteUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado

        jbEditUsuario = new JButton("Editar");
        jbEditUsuario.setBounds(20, 320, 100, 30);
        jbEditUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado

        jbBuscarEditarUsuario = new JButton("Buscar");
        jbBuscarEditarUsuario.setBounds(360, 200, 100, 30);
        jbBuscarEditarUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado

        // Opciones para ver los usuarios
        jlBuscarVerUsuario = new JLabel("Buscar por Correo:");
        jlBuscarVerUsuario.setBounds(540, 120, 250, 30);
        jtBuscarVerUsuario = new JTextField();
        jtBuscarVerUsuario.setBounds(650, 120, 80, 30);

        jbBuscarVerUsuario = new JButton("Buscar");
        jbBuscarVerUsuario.setBounds(650, 160, 80, 30);
        jbBuscarVerUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado

        dt = new DefaultTableModel(new Object[]{"Nombre", "Apellido", "Correo", "Tipo de Usuario"}, 0);
        table = new JTable(dt);
        js = new JScrollPane(table);
        js.setBounds(15, 120, 500, 350);

        jbVolverUsuario = new JButton("Volver");
        jbVolverUsuario.setBounds(650, 440, 120, 30);
        jbVolverUsuario.addActionListener(ctrl_admin); // Asegúrate de que esté registrado
        add(jbVolverUsuario);

        revalidate();
        repaint();
    }

    /**
     * Panel interno con imagen de fondo.
     * La imagen se carga desde: "/Imagenes/Admin.png"
     */
    private class FondoPanel extends JPanel {

        private Image imagen;

        public FondoPanel() {
            // Cargar imagen desde recursos o ruta absoluta
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Admin.png")).getImage();
            // Alternativa: imagen = new ImageIcon("ruta/absoluta/fondo.jpg").getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
