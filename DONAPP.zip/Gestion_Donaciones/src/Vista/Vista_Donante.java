package Vista;

import Control.Control_Donante;
import Modelo.Usuario;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana principal para usuarios donantes dentro del sistema.
 * Permite:
 *   - Explorar campañas activas
 *   - Realizar donaciones a campañas específicas
 *   - Visualizar historial de donaciones propias
 *   - Gestionar método de pago y montos
 * 
 * Diseñada con componentes Swing para interacción simple e intuitiva.
 * Coordina con la clase Control_Donante para manejar eventos.
 */
public class Vista_Donante extends JFrame {
    
    // --------------------------
    // DATOS Y CONTROLADOR
    // --------------------------
    public Usuario usuario;
    public Control_Donante ctrl_donante;
    public Vista_Login login;
    
    // --------------------------
    // COMPONENTES DE INTERFAZ
    // --------------------------
    public JLabel jlTitulo, jlSubTitulo, jlDialogo, jlBuscarCampaña, jlFechaInicio, jlFechaFin, jlMetaPropuesta, jlDescripcion, jlCampaña, jlMonto, jlMetodo_pago, jlTotalDonado;
    public JTextArea jtDescripcion;
    public JComboBox<String> jcMetodo_pago;
    public JTextField jtBuscarCampaña, jtCampaña, jtMonto, jtMetodo_pago;
    public JButton jbCerrar_sesion, jbVerCampañas, jbRealizarDonacion, jbVerDonaciones, jbVerOrganizaciones, jbBuscarCampaña, jbRealizarDonacionCamp, jbConfirmarDonacion, jbVolver;
    public JTable table;
    public DefaultTableModel dtVerCamp, dtVerDona;
    public JScrollPane jsDonante, jsDescripcion;
    public JScrollPane jsVerCamp, jsVerDona;
    public JTable tableVerCamp, tableVerDona;

    /**
     * Constructor principal.
     * Configura:
     *   - Título: "Gestor de donaciones"
     *   - Tamaño fijo (800x520)
     *   - Centrado en pantalla
     *   - Vincula usuario y controlador
     * 
     * @param login Referencia al login para navegación
     * @param usuario Datos del donante autenticado
     */
    public Vista_Donante(Vista_Login login, Usuario usuario) {
        super("Gestor de donaciones");
        this.usuario = usuario;
        this.login = login;
        ctrl_donante = new Control_Donante(this);// Vincula controlador
        setSize(800, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null); // Layout manual

        Menu_Principal(); // Inicializa menú principal
        setVisible(true);
    }

    /**
     * Configura la interfaz principal del donante:
     *   - Muestra bienvenida personalizada
     *   - Botones para funciones clave:
     *       1. Ver campañas activas
     *       2. Realizar donaciones
     *       3. Ver historial de donaciones
     *   - Componentes para búsqueda y visualización de campañas
     *   - Formulario para procesar donaciones
     *   - Tabla para historial de donaciones
     */
    public void Menu_Principal() {
        jlTitulo = new JLabel("Donapp");
        jlTitulo.setBounds(0, 5, 800, 50);
        jlTitulo.setOpaque(true);
        jlTitulo.setBackground(Color.LIGHT_GRAY);
        jlTitulo.setForeground(Color.DARK_GRAY);
        jlTitulo.setFont(new Font("Tahoma", Font.BOLD, 40));
        add(jlTitulo);

        jlSubTitulo = new JLabel("Bienvenido Donante:");
        jlSubTitulo.setBounds(0, 60, 800, 40);
        jlSubTitulo.setOpaque(true);
        jlSubTitulo.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo.setForeground(Color.DARK_GRAY);
        jlSubTitulo.setFont(new Font("Tahoma", Font.BOLD, 25));
        add(jlSubTitulo);

        jlDialogo = new JLabel("Desea:");
        jlDialogo.setBounds(20, 110, 100, 20);
        jlDialogo.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(jlDialogo);

        jbVerCampañas = new JButton("Ver Campañas");
        jbVerCampañas.setBounds(20, 140, 150, 30);
        jbVerCampañas.addActionListener(ctrl_donante);
        add(jbVerCampañas);

        jbRealizarDonacion = new JButton("Realizar Donacion");
        jbRealizarDonacion.setBounds(20, 180, 150, 30);
        jbRealizarDonacion.addActionListener(ctrl_donante);
        add(jbRealizarDonacion);

        jbVerDonaciones = new JButton("Ver Mis Donaciones");
        jbVerDonaciones.setBounds(20, 220, 150, 30);
        jbVerDonaciones.addActionListener(ctrl_donante);
        add(jbVerDonaciones);

        jbCerrar_sesion = new JButton("Cerrar Sesion");
        jbCerrar_sesion.setBounds(600, 440, 150, 30);
        jbCerrar_sesion.addActionListener(ctrl_donante);
        add(jbCerrar_sesion);

        //Ver Campañas
        dtVerCamp = new DefaultTableModel(new Object[]{"Nombre", "Fecha Fin", "Meta Propuesta"}, 0);
        tableVerCamp = new JTable(dtVerCamp);
        jsVerCamp = new JScrollPane(tableVerCamp);
        jsVerCamp.setBounds(10, 120, 400, 330);

        jlBuscarCampaña = new JLabel("Buscar Campaña:");
        jlBuscarCampaña.setBounds(570, 120, 150, 30);

        jtBuscarCampaña = new JTextField();
        jtBuscarCampaña.setBounds(675, 120, 100, 30);

        jbBuscarCampaña = new JButton("Buscar");
        jbBuscarCampaña.setBounds(675, 160, 100, 30);
        jbBuscarCampaña.addActionListener(ctrl_donante);

        jlFechaInicio = new JLabel();
        jlFechaInicio.setBounds(430, 190, 200, 30);

        jlFechaFin = new JLabel();
        jlFechaFin.setBounds(430, 220, 200, 30);

        jlMetaPropuesta = new JLabel();
        jlMetaPropuesta.setBounds(430, 250, 250, 30);

        jlDescripcion = new JLabel("Descripcion:");
        jlDescripcion.setBounds(430, 285, 200, 30);
        jtDescripcion = new JTextArea();
        jtDescripcion.setLineWrap(true);
        jtDescripcion.setWrapStyleWord(true);
        jtDescripcion.setEditable(false);
        jsDescripcion = new JScrollPane(jtDescripcion);
        jsDescripcion.setBounds(430, 315, 300, 70);

        jbRealizarDonacionCamp = new JButton("DONAR");
        jbRealizarDonacionCamp.setBounds(430, 395, 150, 30);
        jbRealizarDonacionCamp.addActionListener(ctrl_donante);

        jbVolver = new JButton("Volver");
        jbVolver.setBounds(600, 440, 150, 30);
        jbVolver.addActionListener(ctrl_donante);
        add(jbVolver);

        //Donar
        jlCampaña = new JLabel("Nombre de la Campaña:");
        jlCampaña.setBounds(20, 120, 200, 30);
        jtCampaña = new JTextField();
        jtCampaña.setBounds(190, 120, 200, 30);

        jlMonto = new JLabel("Cuanto Desea Donar?:");
        jlMonto.setBounds(20, 160, 200, 30);
        jtMonto = new JTextField();
        jtMonto.setBounds(190, 160, 200, 30);

        jlMetodo_pago = new JLabel("Metodo de Pago:");
        jlMetodo_pago.setBounds(20, 200, 200, 30);
        jcMetodo_pago = new JComboBox<>(new String[]{"Tarjeta", "Paypal", "Transferencia", "Crypto"});
        jcMetodo_pago.setBounds(190, 200, 200, 30);

        jbConfirmarDonacion = new JButton("DONAR");
        jbConfirmarDonacion.setBounds(20, 270, 120, 30);
        jbConfirmarDonacion.addActionListener(ctrl_donante);

        //Ver Donaciones
        dtVerDona = new DefaultTableModel(new Object[]{"Campaña", "Monto", "Fecha", "Metodo de Pago"}, 0);
        tableVerDona = new JTable(dtVerDona);
        jsVerDona = new JScrollPane(tableVerDona);
        jsVerDona.setBounds(10, 120, 765, 300);

        jlTotalDonado = new JLabel("Total Donado:");
        jlTotalDonado.setBounds(10, 440, 150, 30);

    }
}
