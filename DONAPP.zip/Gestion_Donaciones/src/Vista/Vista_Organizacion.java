package Vista;

import Control.Control_Organizacion;
import Modelo.Organizacion;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/**
 * Ventana de gestión para organizaciones dentro del sistema de donaciones.
 * Permite:
 *   - Administrar campañas (crear/editar/eliminar/visualizar)
 *   - Generar gráficos estadísticos de donaciones
 *   - Gestionar fechas y metas de campañas
 * 
 * Diseñada con fondo personalizado y componentes Swing para operaciones CRUD.
 * Coordina con la clase Control_Organizacion para manejar eventos.
 */
public class Vista_Organizacion extends JFrame {

    public Control_Organizacion control_org; // Controlador asociado
    
    // --------------------------
    // COMPONENTES PRINCIPALES
    // --------------------------
    public JLabel jlTitulo, jlSubTitulo, jlCampañas, jlGenerarGraficas, jlAñadirCampaña, jlCampañaGrafica, jlNombreCampaña, jlMeta, jlDescripcionCampaña, jlEditarCampaña, jlFechaInicio, jlFechaFin, jlEliminarCampaña;
    public JTextField jtNombreCampaña, jtMeta, jtCampañaGrafica;
    public JTextArea taDescripcionCampaña;
    public JButton jbCampañas, jbElimCampaña, jbAñadirCampaña, jbCampañaGrafica, jbGenerarGraficas, jbVolverOrg, jbCrearCampaña, jbBuscarCampaña, jbEditarCampaña, jbEditCampaña, jbVolver, jbEliminarCampaña;
    public JTable table; // Tabla para listar campañas
    public DefaultTableModel dt; // Modelo de datos para la tabla
    public JScrollPane jsCampañas, jsDescripcion; // Paneles desplazables
    public JSpinner spFechaInicio, spFechaFin; // Selectores de fecha
    public PiePlot plot; // Componente para gráficos de torta
    public JFreeChart chart; // Gráfico generado
    public DefaultPieDataset data; // Datos para gráficos
    public ChartPanel panel; // Contenedor del gráfico
    
    public Vista_Login login; // Referencia al login
    public Organizacion organizacion; // Datos de la organización actual
    
   /**
     * Constructor principal.
     * Configura:
     *   - Título: "Gestor de donaciones"
     *   - Tamaño fijo (800x520)
     *   - Centrado en pantalla
     *   - Panel de fondo personalizado
     *   - Vincula organización y controlador
     * 
     * @param login Referencia a la ventana de login para navegación
     * @param organizacion Datos de la organización autenticada
     */
    public Vista_Organizacion(Vista_Login login, Organizacion organizacion) {
        super("Gestor de donaciones");
        this.login = login;
        this.organizacion = organizacion;
        control_org = new Control_Organizacion(this);
        setSize(800, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        setContentPane(new FondoPanel()); // Fondo personalizado
        setLayout(null); // Layout manual

        Menu(); // Inicializa la interfaz
        setVisible(true);
    }

    /**
     * Configura la interfaz principal de la organización:
     *   - Muestra nombre de la organización como título
     *   - Botones para gestión de campañas (añadir/editar/ver)
     *   - Opción para generar gráficos estadísticos
     *   - Componentes para creación/edición de campañas
     *   - Selectores de fecha para campañas
     */
    public void Menu() {
        // Título principal
        jlTitulo = new JLabel(organizacion.getNombre());
        jlTitulo.setBounds(0, 5, 800, 50);
        jlTitulo.setOpaque(true);
        jlTitulo.setBackground(Color.LIGHT_GRAY);
        jlTitulo.setForeground(Color.DARK_GRAY);
        jlTitulo.setFont(new Font("Tahoma", Font.BOLD, 35));
        add(jlTitulo);

        // Subtítulo
        jlSubTitulo = new JLabel("Administrar organización");
        jlSubTitulo.setBounds(0, 65, 800, 30);
        jlSubTitulo.setOpaque(true);
        jlSubTitulo.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo.setForeground(Color.DARK_GRAY);
        jlSubTitulo.setFont(new Font("Tahoma", Font.BOLD, 25));
        add(jlSubTitulo);

        jlCampañas = new JLabel("Campañas relacionadas:");
        jlCampañas.setBounds(15, 120, 200, 30);
        add(jlCampañas);
        jbCampañas = new JButton("Campañas");
        jbCampañas.setBounds(190, 120, 100, 30);
        jbCampañas.addActionListener(control_org);
        add(jbCampañas);

        jlAñadirCampaña = new JLabel("Añadir campaña:");
        jlAñadirCampaña.setBounds(15, 160, 200, 30);
        add(jlAñadirCampaña);
        jbAñadirCampaña = new JButton("Añadir");
        jbAñadirCampaña.setBounds(190, 160, 100, 30);
        jbAñadirCampaña.addActionListener(control_org);
        add(jbAñadirCampaña);

        jlEditarCampaña = new JLabel("Editar campaña:");
        jlEditarCampaña.setBounds(15, 200, 200, 30);
        add(jlEditarCampaña);
        jbEditarCampaña = new JButton("Editar");
        jbEditarCampaña.setBounds(190, 200, 100, 30);
        jbEditarCampaña.addActionListener(control_org);
        add(jbEditarCampaña);
        
        jlGenerarGraficas = new JLabel("Ver Graficas:");
        jlGenerarGraficas.setBounds(15, 240, 200, 30);
        add(jlGenerarGraficas);
        jbGenerarGraficas = new JButton("Graficar");
        jbGenerarGraficas.setBounds(190, 240, 100, 30);
        jbGenerarGraficas.addActionListener(control_org);
        add(jbGenerarGraficas);

        // Volver a la pantalla de login
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(650, 440, 120, 30);
        jbVolver.addActionListener(control_org);
        add(jbVolver);

        // Ver las campañas relacionadas
        // Tabla para listar campañas
        dt = new DefaultTableModel(new Object[]{"ID", "Nombre", "Fecha Inicio", "Fecha Fin", "Meta Propuesta"}, 0);
        table = new JTable(dt);
        jsCampañas = new JScrollPane(table);

        // Añadir Campañas a la organizacion
        jlNombreCampaña = new JLabel("Nombre de la Campaña:");
        jlNombreCampaña.setBounds(15, 120, 200, 30);
        jtNombreCampaña = new JTextField();
        jtNombreCampaña.setBounds(190, 120, 200, 30);

        jlDescripcionCampaña = new JLabel("Descripción de la Campaña:");
        jlDescripcionCampaña.setBounds(15, 160, 200, 30);
        taDescripcionCampaña = new JTextArea();
        taDescripcionCampaña.setLineWrap(true);
        taDescripcionCampaña.setWrapStyleWord(true);
        jsDescripcion = new JScrollPane(taDescripcionCampaña);
        jsDescripcion.setBounds(190, 160, 200, 60);

        jlFechaInicio = new JLabel("Fecha de Inicio:");
        jlFechaInicio.setBounds(15, 230, 150, 30);
        spFechaInicio = new JSpinner(new SpinnerDateModel());
        spFechaInicio.setBounds(190, 230, 150, 30);
        JSpinner.DateEditor editorInicio = new JSpinner.DateEditor(spFechaInicio, "yyyy-MM-dd");
        spFechaInicio.setEditor(editorInicio);

        jlFechaFin = new JLabel("Fecha de Fin:");
        jlFechaFin.setBounds(15, 270, 150, 30);
        spFechaFin = new JSpinner(new SpinnerDateModel());
        spFechaFin.setBounds(190, 270, 150, 30);
        JSpinner.DateEditor editorFin = new JSpinner.DateEditor(spFechaFin, "yyyy-MM-dd");
        spFechaFin.setEditor(editorFin);

        jlMeta = new JLabel("Meta Propuesta($):");
        jlMeta.setBounds(15, 310, 150, 30);
        jtMeta = new JTextField();
        jtMeta.setBounds(190, 310, 150, 30);

        jbCrearCampaña = new JButton("Crear");
        jbCrearCampaña.setBounds(20, 400, 100, 30);
        jbCrearCampaña.addActionListener(control_org);

        // Editar Campañas
        jbBuscarCampaña = new JButton("Buscar Campaña");
        jbBuscarCampaña.setBounds(400, 120, 150, 30);
        jbBuscarCampaña.addActionListener(control_org);

        jbEditCampaña = new JButton("Editar");
        jbEditCampaña.setBounds(20, 400, 100, 30);
        jbEditCampaña.addActionListener(control_org);
        
        //Graficas
        jlCampañaGrafica = new JLabel("Generar Grafica de:");
        jlCampañaGrafica.setBounds(530, 120, 200, 30);
        jtCampañaGrafica = new JTextField("");
        jtCampañaGrafica.setBounds(650, 120, 100, 30);
        jbCampañaGrafica = new JButton("Graficar");
        jbCampañaGrafica.setBounds(650, 160, 100, 30);
        jbCampañaGrafica.addActionListener(control_org);
                
        // Volver a las opciones de organizacion
        jbVolverOrg = new JButton("Volver");
        jbVolverOrg.setBounds(650, 440, 120, 30);
        jbVolverOrg.addActionListener(control_org);

        revalidate();
        repaint();
    }

    /**
     * Panel interno con imagen de fondo.
     * La imagen se carga desde: "/Imagenes/Organizacion.png"
     */
    private class FondoPanel extends JPanel {

        private Image imagen;

        public FondoPanel() {
            // Cargar imagen
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Organizacion.png")).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
