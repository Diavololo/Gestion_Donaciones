package Vista;

import Control.Control_Login;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

/**
 * Ventana principal para la autenticación de usuarios y organizaciones.
 * Permite:
 *   - Iniciar sesión como usuario (correo/contraseña)
 *   - Registrarse como nuevo usuario (nombre/apellido/correo/contraseña)
 *   - Acceso especial para organizaciones (llave de acceso)
 * 
 * Diseñada con fondo personalizado y componentes Swing para la interacción.
 * Coordina con la clase Control_Login para manejar eventos.
 */
public class Vista_Login extends JFrame {

    // Controlador asociado
    public Control_Login ctrl_main;
    
    // Componentes de la interfaz (botones, campos, etiquetas)
    public JButton jbRegistrarse, jbContraseña, jbCorreo, jbIniciar_sesion, jbRegistrar, jbSalir, jbVolverUser, jbVolverOrg, jbOrganizacion, jbIniciarOrg, jbNombre, jbApellido;
    public JTextField jtCorreo, jtNombre, jtApellido, jtLlave_acceso;
    public JPasswordField jpContraseña;
    public JToggleButton verContraseña; // Alternar visibilidad de contraseña
    public JLabel jlTitulo, jlOrganizacion, jlLlave_acceso, jlSubTitulo, jlSubTitulo2, jlSubTitulo3, jlCorreo, jlContraseña;
    public ImageIcon ver, no_ver; // Íconos para mostrar/ocultar contraseña
    
    
    /**
     * Constructor principal.
     * Configura la ventana:
     *   - Título: "Gestor de donaciones"
     *   - Tamaño fijo (800x520)
     *   - Centrada en pantalla
     *   - Panel de fondo personalizado (FondoPanel)
     *   - Inicializa controlador y componentes
     */
    public Vista_Login() {
        super("Gestor de donaciones");
        setSize(800, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        setContentPane(new FondoPanel());// Establece fondo personalizado
        setLayout(null); // Layout manual (absolute positioning)

        ctrl_main = new Control_Login(this); // Vincula controlador

        Start(); // Inicializa componentes
        setVisible(true);
    }

     /**
     * Inicializa y posiciona todos los componentes gráficos:
     *   - Títulos y subtítulos
     *   - Campos de texto (correo, contraseña, nombre, apellido, llave)
     *   - Botones de acciones (iniciar sesión, registrarse, salir, etc.)
     *   - Botón para mostrar/ocultar contraseña
     * 
     * Nota: Algunos componentes están inicializados pero no visibles inicialmente.
     */
    public void Start() {

        jlTitulo = new JLabel("Donapp");
        jlTitulo.setBounds(0, 5, 800, 50);
        jlTitulo.setOpaque(true);
        jlTitulo.setBackground(Color.LIGHT_GRAY);
        jlTitulo.setForeground(Color.DARK_GRAY);
        jlTitulo.setFont(new Font("Tahoma", Font.BOLD, 40));
        add(jlTitulo);

        jlSubTitulo = new JLabel("Iniciar Sesion:");
        jlSubTitulo.setBounds(0, 60, 800, 40);
        jlSubTitulo.setOpaque(true);
        jlSubTitulo.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo.setForeground(Color.DARK_GRAY);
        jlSubTitulo.setFont(new Font("Tahoma", Font.BOLD, 25));
        add(jlSubTitulo);

        jlSubTitulo2 = new JLabel("Registro:");
        jlSubTitulo2.setBounds(0, 60, 800, 40);
        jlSubTitulo2.setOpaque(true);
        jlSubTitulo2.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo2.setForeground(Color.DARK_GRAY);
        jlSubTitulo2.setFont(new Font("Tahoma", Font.BOLD, 25));

        jlSubTitulo3 = new JLabel("Ingresar como Organizacion:");
        jlSubTitulo3.setBounds(0, 60, 800, 40);
        jlSubTitulo3.setOpaque(true);
        jlSubTitulo3.setBackground(Color.LIGHT_GRAY);
        jlSubTitulo3.setForeground(Color.DARK_GRAY);
        jlSubTitulo3.setFont(new Font("Tahoma", Font.BOLD, 25));

        jbCorreo = new JButton("Correo:");
        jbCorreo.setBounds(260, 150, 103, 29);
        jbCorreo.setEnabled(false);
        add(jbCorreo);
        jtCorreo = new JTextField();
        jtCorreo.setBounds(365, 150, 140, 30);
        add(jtCorreo);

        jbContraseña = new JButton("Contraseña:");
        jbContraseña.setBounds(260, 190, 103, 29);
        jbContraseña.setEnabled(false);
        add(jbContraseña);
        jpContraseña = new JPasswordField();
        jpContraseña.setBounds(365, 190, 140, 30);
        add(jpContraseña);
        
        ver = new ImageIcon(getClass().getResource("/Imagenes/ver.png"));
        no_ver = new ImageIcon(getClass().getResource("/Imagenes/no_ver.png"));
        verContraseña = new JToggleButton(no_ver);
        verContraseña.setBounds(515, 190, 40, 30);
        verContraseña.setBorderPainted(false);
        verContraseña.setContentAreaFilled(false);
        verContraseña.setFocusPainted(false);
        verContraseña.addActionListener(ctrl_main);
        add(verContraseña);
        

        jbNombre = new JButton("Nombre:");
        jbNombre.setBounds(260, 230, 103, 29);
        jbNombre.setEnabled(false);
        jtNombre = new JTextField();
        jtNombre.setBounds(365, 230, 140, 30);

        jbApellido = new JButton("Apellido:");
        jbApellido.setBounds(260, 270, 103, 29);
        jbApellido.setEnabled(false);
        jtApellido = new JTextField();
        jtApellido.setBounds(365, 270, 140, 30);

        jbRegistrar = new JButton("Registrar");
        jbRegistrar.setBounds(335, 330, 120, 30);
        jbRegistrar.addActionListener(ctrl_main);

        jbRegistrarse = new JButton("Registrarse");
        jbRegistrarse.setBounds(265, 260, 120, 30);
        jbRegistrarse.addActionListener(ctrl_main);
        add(jbRegistrarse);

        jbIniciar_sesion = new JButton("Iniciar Sesion");
        jbIniciar_sesion.setBounds(405, 260, 120, 30);
        jbIniciar_sesion.addActionListener(ctrl_main);
        add(jbIniciar_sesion);

        jlOrganizacion = new JLabel("Ingresar como:");
        jlOrganizacion.setBounds(10, 440, 100, 30);
        add(jlOrganizacion);
        jbOrganizacion = new JButton("Organizacion");
        jbOrganizacion.setBounds(100, 440, 110, 30);
        jbOrganizacion.addActionListener(ctrl_main);
        add(jbOrganizacion);

        jlLlave_acceso = new JLabel("Ingrese la llave de acceso:");
        jlLlave_acceso.setBounds(280, 150, 200, 30);

        jtLlave_acceso = new JTextField();
        jtLlave_acceso.setBounds(435, 150, 70, 30);

        jbIniciarOrg = new JButton("Ingresar");
        jbIniciarOrg.setBounds(335, 260, 120, 30);
        jbIniciarOrg.addActionListener(ctrl_main);

        jbSalir = new JButton("Salir");
        jbSalir.setBounds(650, 440, 120, 30);
        jbSalir.addActionListener(ctrl_main);
        add(jbSalir);

        jbVolverOrg = new JButton("Volver");
        jbVolverOrg.setBounds(650, 440, 120, 30);
        jbVolverOrg.addActionListener(ctrl_main);

        jbVolverUser = new JButton("Volver");
        jbVolverUser.setBounds(650, 440, 120, 30);
        jbVolverUser.addActionListener(ctrl_main);

        revalidate();
        repaint();
    }

    /**
     * Panel interno personalizado para dibujar una imagen de fondo.
     * La imagen se carga desde: "/Imagenes/Inicio.png"
     */
    private class FondoPanel extends JPanel {

        private Image imagen;

        public FondoPanel() {
            // Cargar imagen
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Inicio.png")).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Escala la imagen al tamaño del panel
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
